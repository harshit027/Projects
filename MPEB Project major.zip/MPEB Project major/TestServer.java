import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.sql.*;
import java.net.*;
import java.awt.event.*;
import java.io.*;

class TestServer extends JFrame implements ActionListener
{
	static Socket s;
	static ServerSocket ss;
	static BufferedReader in;
     static PrintWriter out;
	JMenuBar jmb;
	JMenu menu;
	JMenuItem viewReport,exit;
	JPanel center;
	String dataFromClient[];
	int i=0;
	TestServer()
	{
		setSize(300,290);
        getContentPane().setLayout(new BorderLayout());
        setTitle("SERVER");
        center=new JPanel();
        ImageIcon image=new ImageIcon("img3.jpg");
        JLabel imgLabel=new JLabel(image,JLabel.CENTER);
        center.add(imgLabel);
        getContentPane().add(center,"Center");

		jmb=new JMenuBar();
		setJMenuBar(jmb);
		menu=new JMenu("Services");
		viewReport=new JMenuItem("ViewReports");
		exit=new JMenuItem("Exit Server");

		viewReport.addActionListener(this);
		exit.addActionListener(this);
		menu.add(viewReport);
		menu.add(exit);

		jmb.add(menu);

		setVisible(true);

		try
		{
            ss=new ServerSocket(3200);
			System.out.println("server started");
			s=ss.accept();
		    in=new BufferedReader(new InputStreamReader(s.getInputStream()));
			out=new PrintWriter(s.getOutputStream(),true);
		    out.println("Connected : "+s);
		 }
		 catch(Exception e)
		 {
			 System.out.println(e);
		 }

		 dataFromClient=new String[22];
		 try
		 {
			 for(int i=0;i<22;i++)
			 {
				 dataFromClient[i]=in.readLine();
			     System.out.println(dataFromClient[i]);
			 }

		 }
		 catch(Exception e)
		 {
			 System.out.println("Error occured :"+e);
		 }

		 try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		    Connection con=DriverManager.getConnection("jdbc:odbc:customer");
		     PreparedStatement pst=con.prepareStatement("insert into customer(cname,fname,category,premiseno,street,colony,district,pin,phone,email,bankaccno,poleno,area,categorysupply,purpose,distance,load,type,fromdate,todate,dates,place) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		     //PreparedStatement pst=con.prepareStatement("insert into customer(cname,fname) values(?,?)");
		     for(int i=0;i<22;i++)
		      {
		    		pst.setString(i+1,dataFromClient[i]);
		      }
				int count=pst.executeUpdate();
		 	    if(count>0)
		 	    {
		 	    	System.out.println("Saved successfully");

		 	    }
		 	    else
		 	    {
		 	    	JOptionPane.showMessageDialog(this,"Error in saving");
		 	    }
		 	    pst.close();
		 	    con.close();
		 	}
		 	catch(Exception e)
		 	{
		 		JOptionPane.showMessageDialog(this,"Error in sql  :"+e);
			}

			/********************************************reciept generation for customer********/
			try
					{
						Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
						Connection tempCon=DriverManager.getConnection("jdbc:odbc:customer");
						Statement st=tempCon.createStatement();
						ResultSet tempRs=st.executeQuery("select * from customer");

						while(tempRs.next())
						{
							i++;
						}
						tempRs.close();
						tempCon.close();
					}
					catch(Exception e)
					{
						e.toString();
					}

					try
					{
						Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
						Connection con=DriverManager.getConnection("jdbc:odbc:customer");
						Statement st=con.createStatement();
						ResultSet rs=st.executeQuery("select * from customer ");
						String temp=new String();
						while(rs.next())
						{
							temp=rs.getString(1);

						}
						out.println("Dear customer, your application is registered ! Application number ="+temp);
						rs.close();
						con.close();
					}
					catch(Exception e)
					{
						e.toString();
		}
			/************************************************************************/

	}
	public static void main(String args[])
	{
		new TestServer();
	}

	public void actionPerformed(ActionEvent ae)
	{
        if(ae.getSource()==viewReport)
        {
			new DatabaseFrame();
		}

		if(ae.getSource()==exit)
		{
			int check=JOptionPane.showConfirmDialog(this,"Are you sure !");
			if(check==JOptionPane.YES_OPTION)
			System.exit(0);
		}
	}
}

class DatabaseFrame extends JFrame
{
	JTable table;
	String data[][];
	String heads[]={"Application No","Name","Phone No","Email ID","Date"};
	int i;
	DatabaseFrame()
	{
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection tempCon=DriverManager.getConnection("jdbc:odbc:customer");
			Statement st=tempCon.createStatement();
			ResultSet tempRs=st.executeQuery("select * from customer");

			while(tempRs.next())
			{
				i++;
			}
			tempRs.close();
			tempCon.close();
		}
		catch(Exception e)
		{
			e.toString();
		}
		setSize(500,200);
		setTitle("Reports");
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con=DriverManager.getConnection("jdbc:odbc:customer");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from customer");
			data=new String[i][5];
			i=0;
			while(rs.next())
			{
				data[i][0]=rs.getString(1);
				data[i][1]=rs.getString(2);
				data[i][2]=rs.getString(10);
				data[i][3]=rs.getString(11);
                data[i][4]=rs.getString(22);
				i++;
			}
			rs.close();
			con.close();
		}
		catch(Exception e)
		{
			e.toString();
		}
		table=new JTable(data,heads);
		JScrollPane jsp=new JScrollPane(table);
		getContentPane().add(jsp);
        setVisible(true);
	}
}

