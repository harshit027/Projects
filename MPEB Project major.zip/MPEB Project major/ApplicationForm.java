import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.Date;

public class ApplicationForm extends JApplet implements ActionListener
{
	 JPanel north,center,south;
	 JButton submit;
	 static JTextField consumerNameTF,fathersNameTF,premiseNoTF,streetTF,colonyTF,pinTF,phoneNoTF,emailTF,bankAccNoTF,t13,t14;
	 static JLabel consumerNameLB,categoryLB,fathersNameLB,premiseNoLB,districtLB,streetLB,colonyLB,pinLB,phoneNoLB,emailLB,bankAccNoLB,l13,l14;
     static JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
     static JComboBox districtCB;
     static JComboBox jc2,categoryCB,jc3;
     static Socket s;
     static BufferedReader in;
     static PrintWriter out;
     static Date date;
	public void init()
	{
		setSize(600,700);
		setBackground(Color.lightGray);
		getContentPane().setLayout(new BorderLayout(30,30));
		consumerNameLB=new JLabel("Name");
		fathersNameLB=new JLabel("Father's Name");
		premiseNoLB=new JLabel("Premise No.");
		districtLB=new JLabel("District");
		streetLB=new JLabel("Street");
		colonyLB=new JLabel("Colony");
		pinLB=new JLabel("Pin Code");
		phoneNoLB=new JLabel("Phone No.");
		emailLB=new JLabel("Email ID");
		bankAccNoLB=new JLabel("Bank Account No.");
		categoryLB=new JLabel("Category");

		consumerNameTF=new JTextField(20);
		fathersNameTF=new JTextField(20);
		premiseNoTF=new JTextField(20);
		streetTF=new JTextField(20);
		colonyTF=new JTextField(20);
		pinTF=new JTextField(20);
		phoneNoTF=new JTextField(20);
		emailTF=new JTextField(20);
		bankAccNoTF=new JTextField(20);
		categoryCB=new JComboBox();
		categoryCB.addItem("General");
		categoryCB.addItem("SC");
		categoryCB.addItem("ST");
		categoryCB.addItem("OBC");
		categoryCB.addItem("Others");
		districtCB=new JComboBox();
		districtCB.addActionListener(this);
		districtCB.addItem("Bhopal");
		districtCB.addItem("Gwalior");
		districtCB.addItem("Indore");
		districtCB.addItem("Jabalpur");

		north=new JPanel();
		north.setLayout(new GridLayout(3,2,2,2));
		Border etched1=BorderFactory.createEtchedBorder();
		Border titled1=BorderFactory.createTitledBorder(etched1,"General");
		north.setBorder(titled1);
        north.add(consumerNameLB);
		north.add(consumerNameTF);
		north.add(fathersNameLB);
		north.add(fathersNameTF);
		north.add(categoryLB);
		north.add(categoryCB);

		getContentPane().add(north,"North");

		center=new JPanel();
		Border etched=BorderFactory.createEtchedBorder();
		Border titled=BorderFactory.createTitledBorder(etched,"Address Of Location");
		center.setBorder(titled);
		GridLayout gl=new GridLayout(8,2);
		gl.setVgap(2);
		gl.setHgap(2);

        center.setLayout(gl);
		center.add(premiseNoLB);
		center.add(premiseNoTF);
		center.add(streetLB);
		center.add(streetTF);
		center.add(colonyLB);
		center.add(colonyTF);
		center.add(districtLB);
		center.add(districtCB);
		center.add(pinLB);
		center.add(pinTF);
		center.add(phoneNoLB);
		center.add(phoneNoTF);
		center.add(emailLB);
		center.add(emailTF);
		center.add(bankAccNoLB);
		center.add(bankAccNoTF);
		getContentPane().add(center,"Center");


		south=new JPanel();
		south.setLayout(new BorderLayout(0,10));
		JPanel south1=new JPanel();
		south1.setLayout(new GridLayout(9,2,2,2));
		JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;


		l1=new JLabel("Nearest pole no. where connection is expected");
		t1=new JTextField(20);
		l2=new JLabel("Built up area of the premises (sq mts)");
        t2=new JTextField(20);
        l3=new JLabel("Category of supply");
        t3=new JTextField(20);
         jc3=new JComboBox();
        jc3.addItem("Domestic");
        jc3.addItem("Commercial");
        jc3.addItem("Agriculture");
        jc3.addItem("Industrial");
        jc3.addItem("Water Supply");
        l4=new JLabel("Purpose of supply");
        t4=new JTextField(20);
        l5=new JLabel("Type of supply");
        jc2=new JComboBox();
        jc2.addItem("Permanent");
        jc2.addItem("Temporary");
        jc2.addActionListener(this);
        l6=new JLabel("Distance from the nearest mains (mts)");
        t6=new JTextField(20);
        l7=new JLabel("Proposed load (fill the table and write total)");
        t7=new JTextField(20);
        l13=new JLabel("From date (DD-MM-YYYY)");
        t13=new JTextField(20);
        l14=new JLabel("To date (DD-MM-YYYY)");
        t14=new JTextField(20);
        t13.setText(null);
        t14.setText(null);

        this.l13.setVisible(false);
		this.t13.setVisible(false);
		this.l14.setVisible(false);
		this.t14.setVisible(false);

        south1.add(l1);
        south1.add(t1);
        south1.add(l2);
        south1.add(t2);
        south1.add(l3);
        south1.add(jc3);
        south1.add(l4);
        south1.add(t4);
        south1.add(l6);
        south1.add(t6);
        south1.add(l7);
        south1.add(t7);
        south1.add(l5);
        south1.add(jc2);
        south1.add(l13);
        south1.add(t13);
        south1.add(l14);
        south1.add(t14);

        Border etched2=BorderFactory.createEtchedBorder();
        Border titled2=BorderFactory.createTitledBorder(etched2,"Other Details");
        south1.setBorder(titled2);
        south.add(south1,"North");

        JPanel south3=new JPanel();
        south3.setLayout(new BorderLayout());
        JPanel south31=new JPanel();

        String heads[]={"Item","Power(watts)","Number","Total"};
        String data[][]={
			                      {"Bulb","60",null,null},
			                      {"Tubelight","50",null,null},
			                      {"Fan","60",null,null},
			                      {"Tape","100",null,null},
			                      {"Television","90",null,null},
			                      {"Mixie","375",null,null},
			                      {"Electric Iron","750",null,null},
			                      {"Fridge","150",null,null},
			                      {"Cooler","150",null,null},
			                      {"Heater","1000",null,null},
			                      {"Washing Machine","750",null,null},
			                      {"Geyser","2000",null,null},
			                      {"Microwave","2000",null,null},
			                      {"Air Conditioner(1 ton)","1500",null,null},
			                      {"Air Conditioner(1.5 ton)","2250",null,null},
			                      {"Computer","100",null,null},
			                      {"Printer","150",null,null},
			                      {"Pump Set","375",null,null},
			                      {null,null,null,null},
			                      {null,null,null,null},
			                      {null,null,null,null},
			                      {null,null,null,null},
			                      {null,null,null,null},
			                      {null,null,"Total",null}
							  };
        JTable table=new JTable(data,heads);
        JScrollPane jsp=new JScrollPane(table);
        south31.add(jsp);
        south3.add(south31,"South");


        south.add(south3,"Center");

        JPanel south2=new JPanel();
        south2.setLayout(new BorderLayout(10,10));
        JPanel south21=new JPanel();
        south21.setLayout(new FlowLayout());
        date=new Date();

	    l8=new JLabel("Date");
        t8=new JTextField(10);
        t8.setText(date.getDate()+"-"+(date.getMonth()+1)+"-"+(date.getYear()+1900));
       l9=new JLabel("Place");
       t9=new JTextField(10);
       south21.add(l8);
       south21.add(t8);
       south21.add(l9);
       south21.add(t9);
       south2.add(south21,"West");

        JPanel south22=new JPanel();
        south22.setLayout(new FlowLayout());
        submit=new JButton("Submit");
        submit.setBackground(Color.yellow);
        submit.addActionListener(this);
        south22.add(submit);
        south2.add(south22,"South");

        JPanel south23=new JPanel();
        south23.setLayout(new FlowLayout(FlowLayout.LEFT,30,10));
        Border etched3=BorderFactory.createEtchedBorder();
		Border titled3=BorderFactory.createTitledBorder(etched3,"Previous Dues");
		south23.setBorder(titled3);
        ButtonGroup g1=new ButtonGroup();
        l10=new JLabel("Any previous electricity dues (if yes provide details to the nearest DC)");
        JRadioButton
        r1=new JRadioButton("Yes",false),
        r2=new JRadioButton("No",false);

        g1.add(r1);
        g1.add(r2);
        south23.add(l10);
        south23.add(r1);
        south23.add(r2);
        south2.add(south23,"North");
        south.add(south2,"South");
        add(south,"South");

        try
        {
			s=new Socket("127.0.0.1",3200);
			in=new BufferedReader(new InputStreamReader(s.getInputStream()));
			out=new PrintWriter(s.getOutputStream(),true);
			JOptionPane.showMessageDialog(this," "+in.readLine());
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this,"Error in connection");
		}
		try
		{
			//s.close();
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this,"Error in closing ");
		}
	}

	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==submit)
		{

			if(       consumerNameTF.getText().equals("")||
			         fathersNameTF.getText().equals("")||
			          premiseNoTF.getText().equals("")||
			          streetTF.getText().equals("")||
		             colonyTF.getText().equals("")||
			          pinTF.getText().equals("")||
			          phoneNoTF.getText().equals("")||
			          emailTF.getText().equals("")||
			          bankAccNoTF.getText().equals("")||
			          t1.getText().equals("")||
			          t2.getText().equals("")||
			          t4.getText().equals("")||
			          t6.getText().equals("")||
			          t7.getText().equals("")||
			          t8.getText().equals("")||
			          t9.getText().equals("")
			          )
	          JOptionPane.showMessageDialog(this,"All fields are mandatory");

          else
          {
			String dataToServer[]=new String[22];
			dataToServer[0]=consumerNameTF.getText();
			dataToServer[1]=fathersNameTF.getText();
			dataToServer[2]=""+categoryCB.getSelectedItem();
			dataToServer[3]=premiseNoTF.getText();
			dataToServer[4]=streetTF.getText();
			dataToServer[5]=colonyTF.getText();
			dataToServer[6]=""+districtCB.getSelectedItem();
			dataToServer[7]=pinTF.getText();
			dataToServer[8]=phoneNoTF.getText();
			dataToServer[9]=emailTF.getText();
			dataToServer[10]=bankAccNoTF.getText();
			dataToServer[11]=t1.getText();
			dataToServer[12]=t2.getText();
			dataToServer[13]=""+jc3.getSelectedItem();
			dataToServer[14]=t4.getText();
			dataToServer[15]=t6.getText();
			dataToServer[16]=t7.getText();
			dataToServer[17]=""+jc2.getSelectedItem();
			dataToServer[18]=t13.getText();
			dataToServer[19]=t14.getText();
			dataToServer[20]=t8.getText();
			dataToServer[21]=t9.getText();


				try
                {
		        	for(int i=0;i<22;i++)
		        	{
		        		out.println(dataToServer[i]);
		        	}
		       	    JOptionPane.showMessageDialog(this,in.readLine());
		        }
		        catch(Exception e)
		        {
			    	JOptionPane.showMessageDialog(this,"Error");
			    }

			}

		}


		if(ae.getSource()==districtCB)
		{
			if(districtCB.getSelectedItem().equals("Jabalpur"))
			{
				this.pinTF.setText("482");
				this.phoneNoTF.setText("0761-");
			}
			if(districtCB.getSelectedItem().equals("Bhopal"))
			{
				this.pinTF.setText("481");
				this.phoneNoTF.setText("0755-");
			}
			if(districtCB.getSelectedItem().equals("Gwalior"))
			{
				this.pinTF.setText("484");
				this.phoneNoTF.setText("0751-");
			}
			if(districtCB.getSelectedItem().equals("Indore"))
			{
				this.pinTF.setText("485");
				this.phoneNoTF.setText("0731-");
			}
		}

		if(ae.getSource()==jc2)
		{
			if(this.jc2.getSelectedItem().equals("Permanent"));
			{
				this.l13.setVisible(false);
				this.t13.setVisible(false);
				this.l14.setVisible(false);
				this.t14.setVisible(false);

			}
			if(this.jc2.getSelectedItem().equals("Temporary"));
			{
				this.l13.setVisible(true);
				this.t13.setVisible(true);
				this.l14.setVisible(true);
				this.t14.setVisible(true);

			}
		}
	}
}