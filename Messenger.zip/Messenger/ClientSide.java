import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.sql.*;
import java.net.*;
import java.io.*;
import java.util.Date;

class LoginPanel extends JPanel implements ActionListener
{
	    public static String dateOfLog,startTime,endTime;
	    public static int clientId;
	    public static JPanel centerPanel,entryPanel;
	    JLabel lbUsername,lbPassword;
		static JTextField tfUsername;
		static JPasswordField tfPassword;
		public static JButton btLogin;
		ChatPanel  chatPanel;
		JPanel usernamePanel,passwordPanel;
		public static CardLayout loginCards=new CardLayout();
		Color currentColor;
		LoginPanel()
		{
			setLayout(new BorderLayout(20,20));
			lbUsername=new JLabel("Username");
			lbPassword=new JLabel("Password");
			tfUsername=new JTextField(15);
			tfPassword=new JPasswordField(15);
			//tfPassword.setEchoChar('*');
			usernamePanel=new JPanel();
			usernamePanel.setLayout(new FlowLayout(FlowLayout.LEFT,20,20));
			passwordPanel=new JPanel();
			passwordPanel.setLayout(new FlowLayout(FlowLayout.LEFT,20,20));
			usernamePanel.add(lbUsername);
			usernamePanel.add(tfUsername);
			passwordPanel.add(lbPassword);
			passwordPanel.add(tfPassword);

            entryPanel=new JPanel();
			entryPanel.setLayout(new BorderLayout(30,30));
			entryPanel.add(usernamePanel,"North");
			entryPanel.add(passwordPanel,"Center");


             chatPanel=new ChatPanel();
             centerPanel=new JPanel();
			 centerPanel.setLayout(loginCards);
			 centerPanel.add(entryPanel,"EntryPanel");
			 centerPanel.add(chatPanel,"ChatPanel");
			add(centerPanel,"Center");

			JPanel bottomPanel=new JPanel();
			btLogin=new JButton("LOGIN");
			btLogin.addActionListener(this);
			btLogin.setVisible(true);
			btLogin.addMouseListener(new MouseAdapter()
			                                                  {
																  public void mouseEntered(MouseEvent me)
																  {
																	  if(me.getSource()==btLogin)
																	  {
																		  currentColor=btLogin.getBackground();
																		  btLogin.setBackground(Color.yellow);
																	  }
																  }
															  });
            btLogin.addMouseListener(new MouseAdapter()
						                                                  {
																			  public void mouseExited(MouseEvent me)
																			  {
																				  if(me.getSource()==btLogin)
																				  {
																					  btLogin.setBackground(currentColor);
																				  }
																			  }
															  });
			add(bottomPanel,"South");
			bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER,10,10));
			bottomPanel.add(btLogin);


		}
		public void actionPerformed(ActionEvent ae)
		{
			int check=0;
			if(ae.getSource()==btLogin)
			{
				try
				{
					String qry1="select * from user";
					String dsn="chat_users";
					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					Connection con1=DriverManager.getConnection("jdbc:odbc:"+dsn);
					Statement st1=con1.createStatement();
					ResultSet rs1=st1.executeQuery(qry1);
					while(rs1.next())
					{
						if(rs1.getString(2).equalsIgnoreCase(this.tfUsername.getText()) && rs1.getString(3).equalsIgnoreCase(this.tfPassword.getText()))
						{
							check=1;
							clientId=rs1.getInt(1);
						}

					}
					if(check==1)
					{
						JOptionPane.showMessageDialog(this,"Logged in sucessfully !");
						this.loginCards.show(centerPanel,"ChatPanel");
						ClientSide.newUserBtn.setVisible(false);
						ClientSide.chatBtn.setVisible(false);
						this.btLogin.setVisible(false);
						Date dt=new Date();
						dateOfLog=dt.getDate()+"-"+(dt.getMonth()+1)+"-"+(dt.getYear()+1900);
						startTime=dt.getHours()+":"+dt.getMinutes()+":"+dt.getSeconds();
                        ChatPanel.chatArea.setText("Welcome , Mr "+this.tfUsername.getText());
					}
					else
					{
						JOptionPane.showMessageDialog(this,"Password not recognized");
					}
					rs1.close();
					con1.close();
				}
				catch(Exception e)
				{
					System.out.println("Error :"+e);
			    }
			}
		}
}

class RegisterPanel extends JPanel implements ActionListener
{
	JLabel rpLabels[]=null;
	JTextField rpTextFields[]=null;
	JButton registerBtn;
	JPanel formPnl,regPnl;
	String captions[]={"User ID","Username","Password","Phone","Mobile","Address"};
    Color currentColor;
	RegisterPanel()
	{
		setLayout(new BorderLayout(20,20));
		formPnl=new JPanel();
		formPnl.setLayout(new GridLayout(6,2,10,10));
		rpLabels=new JLabel[6];
	    rpTextFields=new JTextField[6];
		for(int i=0;i<6;i++)
		{
			rpLabels[i]=new JLabel(captions[i]);
			formPnl.add(rpLabels[i]);
			rpTextFields[i]=new JTextField();
			formPnl.add(rpTextFields[i]);
		}
        add(formPnl,"Center");

        regPnl=new JPanel();
		regPnl.setLayout(new FlowLayout(FlowLayout.CENTER));
		registerBtn=new JButton("REGISTER");
		registerBtn.addActionListener(this);
		registerBtn.addMouseListener(new MouseAdapter()
					                                                  {
																		  public void mouseEntered(MouseEvent me)
																		  {
																			  if(me.getSource()==registerBtn)
																			  {
																				  currentColor=registerBtn.getBackground();
																				  registerBtn.setBackground(Color.yellow);
																			  }
																		  }
																	  });
        registerBtn.addMouseListener(new MouseAdapter()
			                                             {
														     public void mouseExited(MouseEvent me)
															  {
																  if(me.getSource()==registerBtn)
																  {
																	  registerBtn.setBackground(currentColor);
																  }
															  }
														  });
		regPnl.add(registerBtn);
		add(regPnl,"South");
	}

	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==registerBtn)
		{
			try
			{
				//JOptionPane.showMessageDialog(this,"WORKING");
				String qry1="insert into user(userid,username,password,phone,mobile,address) values(?,?,?,?,?,?)";
				String dsn="chat_users";
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				Connection con1=DriverManager.getConnection("jdbc:odbc:"+dsn);
				PreparedStatement pst1=con1.prepareStatement(qry1);

				pst1.setInt(1,Integer.parseInt(this.rpTextFields[0].getText()));
				pst1.setString(2,this.rpTextFields[1].getText());
				pst1.setString(3,this.rpTextFields[2].getText());
				pst1.setString(4,this.rpTextFields[3].getText());
				pst1.setString(5,this.rpTextFields[4].getText());
				pst1.setString(6,this.rpTextFields[5].getText());

				int count=pst1.executeUpdate();
				if(count>0)
				{
					JOptionPane.showMessageDialog(this,"You are registered ! ");
				}
				else
				{
					JOptionPane.showMessageDialog(this,"Error occured !");
				}
				con1.close();
			}
			catch(Exception e)
			{
				e.toString();
			}
		}
	}
}

class ChatPanel extends JPanel implements ActionListener
{

	JButton sendBtn,logoutBtn;
	public static  JPanel logoutPanel,sendPanel,messagePanel;
	public static  JTextArea chatArea,writeArea;
	Color currentBackground,currentForeground;

	ChatPanel ()
	{
		setLayout(new BorderLayout(10,10));

        logoutPanel=new JPanel();
		logoutPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
		logoutBtn=new JButton("LOGOUT");
		logoutBtn.addActionListener(this);
		logoutBtn.setBackground(Color.yellow);
		logoutBtn.addMouseListener(new MouseAdapter()
																   {
																	   public void mouseEntered(MouseEvent me)
																	   {
																		   if(me.getSource()==logoutBtn)
																		   {
																			   currentBackground=logoutBtn.getBackground();
																			   currentForeground=logoutBtn.getForeground();
																			   logoutBtn.setBackground(Color.red);
																			   logoutBtn.setForeground(Color.white);
																		   }
																	   }
																   });
        logoutBtn.addMouseListener(new MouseAdapter()
		   												   {
															   public void mouseExited(MouseEvent me)
															   {
																   if(me.getSource()==logoutBtn)
																   {
																	   logoutBtn.setBackground(currentBackground);
																	   logoutBtn.setForeground(currentForeground);
																   }
															   }
														   });

		logoutPanel.add(logoutBtn);
		add(logoutPanel,"North");

        messagePanel=new JPanel();
        messagePanel.setLayout(new BorderLayout(10,10));
        chatArea=new JTextArea(20,40);
		messagePanel.add(new JScrollPane(chatArea),"Center");
		messagePanel.add(chatArea,"Center");
        messagePanel.add(new JScrollPane(chatArea) ,"Center");
        add(messagePanel,"Center");

	    sendPanel=new JPanel();
		sendPanel.setLayout(new BorderLayout(10,10));
		sendBtn=new JButton("SEND");
		sendBtn.addActionListener(this);
		sendBtn.setBackground(Color.yellow);

		sendBtn.addMouseListener(new MouseAdapter()
														   {
															   public void mouseEntered(MouseEvent me)
															   {
																   if(me.getSource()==sendBtn)
																   {
																	   currentBackground=sendBtn.getBackground();
																	   currentForeground=sendBtn.getForeground();
																	   sendBtn.setBackground(Color.red);
																	   sendBtn.setForeground(Color.white);
																   }
															   }
														   });
        sendBtn.addMouseListener(new MouseAdapter()
        												   {
															   public void mouseExited(MouseEvent me)
															   {
																   if(me.getSource()==sendBtn)
																   {
																	   sendBtn.setBackground(currentBackground);
																	   sendBtn.setForeground(currentForeground);
																   }
															   }
														   });

		writeArea=new JTextArea(5,40);



		sendPanel.add(writeArea,"Center");
		sendPanel.add(new JScrollPane(writeArea),"Center");
		sendPanel.add(sendBtn,"East");
		add(sendPanel,"South");
		setBackground(Color.magenta);


	}

	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==logoutBtn)
		{
			JOptionPane.showMessageDialog(this,"Logged out successfully !");
			try
			{
				//ClientSide.s.close();
			}
			catch (Exception e)
			{
				e.toString();
			}
			ClientSide.cards.show(ClientSide.formsPnl,"TitlePanel");
			ClientSide.newUserBtn.setVisible(true);
			ClientSide.chatBtn.setVisible(true);
			LoginPanel.loginCards.show(LoginPanel.centerPanel,"EntryPanel");
			LoginPanel.btLogin.setVisible(true);
			LoginPanel.tfPassword.setText("");
			LoginPanel.tfUsername.setText("");
			this.chatArea.setText("");
			Date dt1=new Date();
			LoginPanel.endTime=dt1.getHours()+":"+dt1.getMinutes()+":"+dt1.getSeconds();
			//log updation
			try
			{
				String qry="INSERT into log(clientID,startTime,endTime,dateOfLog) values(?,?,?,?)";
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				String dsnLog="log_data";
				Connection con2=DriverManager.getConnection("jdbc:odbc:"+dsnLog);
				PreparedStatement pst2=con2.prepareStatement(qry);
				pst2.setInt(1,LoginPanel.clientId);
				pst2.setString(2,LoginPanel.startTime);
				pst2.setString(3,LoginPanel.endTime);
				pst2.setString(4,LoginPanel.dateOfLog);

			    int count=pst2.executeUpdate();

				if(count>0)
				{
					JOptionPane.showMessageDialog(this,"Log Updated !");
				}
				else
				{
					JOptionPane.showMessageDialog(this,"Error occured !");
				}
				con2.close();
			}
			catch(Exception e)
			{
				e.toString();
			}
			//-----------------
		}

		if(ae.getSource()==sendBtn)
		{
			try
			{
				/*PrintWriter out = new PrintWriter(ClientSide.s.getOutputStream(),true);
		        this.chatArea.setText(this.chatArea.getText()+"\n"+LoginPanel.tfUsername.getText()+" : "+this.writeArea.getText());
		        out.println(LoginPanel.tfUsername.getText()+" : "+this.writeArea.getText());
				 this.writeArea.setText("");*/
				 //s = new Socket("127.0.0.1",3400);
				 PrintWriter pw = new PrintWriter(ConnecToServer.s.getOutputStream(),true);
				 pw.println(LoginPanel.tfUsername.getText()+" : "+this.writeArea.getText());
				 //taMessage.setText(taMessage.getText()+"\nYou :"+taSendMessage.getText());
			     this.writeArea.setText("");
			  }
              catch(Exception e)
			   {
				   e.toString();
			   }
		   }
	}
}


class ClientSide extends JFrame implements ActionListener
{
	//Menu Variables
	JMenuBar jmb;
	JMenu smileys,fonts,txtColor,styles;
	JMenuItem smiley1,smiley2,smiley3;
	String fontCaptions[]={"Verdana","Arial","Vrinda","Tahoma","TimesNewRoman"};
	String styleCaptions[]={"Regular","Bold","Italic","Bold Italic"};
	JMenuItem fontStyles[]=null;
	JMenuItem fontTypes[]=null;
	String colorCaptions[]={"Red","Blue","Green","Orange","Yellow","Cyan","Magenta","Black","Pink"};
	Color colorChoice[]={Color.red,Color.blue,Color.green,Color.orange,Color.yellow,Color.cyan,Color.magenta,Color.black,Color.pink};
	JMenuItem colors[]=null;
	String currentFont="Verdana";
	//------------------------------------

	JPanel buttonsPnl;
	public static JPanel formsPnl=new JPanel();
	RegisterPanel regPnl;
	LoginPanel loginPnl;
    public JPanel titlePnl;
    JLabel  titleLbl;

	public static CardLayout cards=new CardLayout();
	public static JButton newUserBtn,chatBtn;
	Color currentColor;
	//public static Socket s=null;
	ConnecToServer clientSocket;
	//public static BufferedReader in;
	//public static PrintWriter out;

	ClientSide()
	{
		setSize(400,400);
		setResizable(false);
		setTitle("CHIT--CHAT");
		getContentPane().setLayout(new BorderLayout(10,10));
        newUserBtn=new JButton("NEW USER");
        newUserBtn.setBackground(Color.red);
        newUserBtn.setForeground(Color.white);
        chatBtn=new JButton("CHAT ROOM");
        chatBtn.setBackground(Color.red);
        chatBtn.setForeground(Color.white);
        getContentPane().setBackground(Color.yellow);
       //Menu Code
        jmb=new JMenuBar();
        jmb.setBackground(Color.yellow);
		smileys=new JMenu("Smileys");
		fonts=new JMenu("Fonts");
		txtColor=new JMenu("Text Color");
		styles=new JMenu("Styles");
		setJMenuBar(jmb);

		smiley1=new JMenuItem("Smiley1");
		smiley2=new JMenuItem("Smiley2");
		smiley3=new JMenuItem("Smiley3");
		smiley1.setBackground(Color.white);
		smiley2.setBackground(Color.white);
		smiley3.setBackground(Color.white);

		fontStyles=new JMenuItem[4];
		for(int i=0;i<4;i++)
		{
			fontStyles[i]=new JMenuItem(styleCaptions[i]);
			fontStyles[i].setBackground(Color.white);
			fontStyles[i].addActionListener(this);
			styles.add(fontStyles[i]);
		}
		fontTypes=new JMenuItem[5];
		for(int i=0;i<5;i++)
		{
			fontTypes[i]=new JMenuItem(fontCaptions[i]);
			fontTypes[i].setBackground(Color.white);
			fontTypes[i].addActionListener(this);
			fonts.add(fontTypes[i]);
		}

	    colors=new JMenuItem[9];
		for(int i=0;i<9;i++)
	    {
			colors[i]=new JMenuItem(colorCaptions[i]);
			colors[i].setBackground(Color.white);
			colors[i].addActionListener(this);
			txtColor.add(colors[i]);
		}
		smileys.add(smiley1);
		smileys.add(smiley2);
		smileys.add(smiley3);

	    jmb.add(smileys);
		jmb.add(fonts);
		jmb.add(txtColor);
		jmb.add(styles);

        //-----------------------
        newUserBtn.addActionListener(this);
        chatBtn.addActionListener(this);
        newUserBtn.addMouseListener(new MouseAdapter()
         														 {
																	 public void mouseEntered(MouseEvent me)
																	 {
																		 if(me.getSource()==newUserBtn)
																		 {
																			 currentColor=newUserBtn.getBackground();
																			 newUserBtn.setBackground(Color.blue);
																		 }
																	 }
																 }
																 );
		newUserBtn.addMouseListener(new MouseAdapter()
         														 {
																	 public void mouseExited(MouseEvent me)
																	 {
																		 if(me.getSource()==newUserBtn)
																		 {

																			 newUserBtn.setBackground(currentColor);
																		 }
																	 }
																 }
																 );
		chatBtn.addMouseListener(new MouseAdapter()
         														 {
																	 public void mouseEntered(MouseEvent me)
																	 {
																		 if(me.getSource()==chatBtn)
																		 {
																			 currentColor=chatBtn.getBackground();
																			 chatBtn.setBackground(Color.blue);
																		 }
																	 }
																 }
																 );

        chatBtn.addMouseListener(new MouseAdapter()
		         														 {
																			 public void mouseExited(MouseEvent me)
																			 {
																				 if(me.getSource()==chatBtn)
																				 {

																					 chatBtn.setBackground(currentColor);
																				 }
																			 }
																		 }
																 );
        buttonsPnl=new JPanel();
        buttonsPnl.setLayout(new FlowLayout(FlowLayout.CENTER,30,10));
        buttonsPnl.add(newUserBtn);

        buttonsPnl.add(chatBtn);
        getContentPane().add(buttonsPnl,"South");

        regPnl=new RegisterPanel();
        loginPnl=new LoginPanel();

        titlePnl=new JPanel();
        //titleLbl=new JLabel("CHIT--CHAT");
        //titleLbl.setFont(new Font("TimesRoman",Font.BOLD,60));
        //titleLbl.setForeground(Color.blue);
        ImageIcon image=new ImageIcon("img.jpg");
        JLabel imageLabel=new JLabel(image,JLabel.CENTER);
	    titlePnl.add(imageLabel,"Center");



        formsPnl.setLayout(cards);
        formsPnl.add(titlePnl,"TitlePanel");
        formsPnl.add(regPnl,"RegisterPanel");
        formsPnl.add(loginPnl,"LoginPanel");
        getContentPane().add(formsPnl,"Center");

        /*try
        {
			in=new BufferedReader(new InputStreamReader(s.getInputStream()));
			out=new PrintWriter(s.getOutputSteam(),true);
		}
		catch(Exception e)
		{
			e.toString();
		}*/
        clientSocket=new ConnecToServer(this);
   		setVisible(true);

   		 //Socket code
		        /*try
				{
					//s = new Socket("127.0.0.1",3400);
					PrintWriter pw = new PrintWriter(clientSocket.s.getOutputStream(),true);
					pw.println(ChatPanel.writeArea.getText());
					//taMessage.setText(taMessage.getText()+"\nYou :"+taSendMessage.getText());
			        ChatPanel.writeArea.setText("");
				}

				catch(Exception e)
				{
				   e.toString();
	            }*/
	}

	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==newUserBtn)
		{
           this.cards.show(formsPnl,"RegisterPanel");
		}

		if (ae.getSource()==chatBtn)
		{
			this.cards.show(formsPnl,"LoginPanel");
		}

        for(int i=0;i<4;i++)
		{
			if(ae.getSource()==fontStyles[i])
			{
				ChatPanel.writeArea.setFont(new Font(this.currentFont,i,20));
				ChatPanel.chatArea.setFont(new Font(this.currentFont,i,20));
			}
		}
		for(int i=0;i<5;i++)
		{
			if(ae.getSource()==fontTypes[i])
			{
				ChatPanel.writeArea.setFont(new Font(fontCaptions[i],0,20));
				ChatPanel.chatArea.setFont(new Font(fontCaptions[i],0,20));
				this.currentFont=fontCaptions[i];
			}
		}
		for(int i=0;i<9;i++)
		{
			if(ae.getSource()==colors[i])
		    {
		    	ChatPanel.writeArea.setForeground(colorChoice[i]);
		    	ChatPanel.chatArea.setForeground(colorChoice[i]);
		    }
		}
	}

	public static void main(String args[])
	{
         new ClientSide();
	}
}


class ConnecToServer extends Thread {
	ClientSide  ref;
	static Socket s;
	ConnecToServer (ClientSide ref) {
		this.ref = ref;
		System.out.println("Connecting");
		try {
			s= new Socket("127.0.0.1", 3400);
			System.out.println("Connected To Client : "+s);
		}
		catch(Exception e){
			System.out.println("Error :"+e);
		}
		start();
	}
	public void run() {
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
			String mess="";
			while(true) {
				mess = in.readLine();
				ChatPanel.chatArea.setText(ChatPanel.chatArea.getText()+"\n"+mess);
			}
		}
		catch(Exception e){
		}
	}
}

