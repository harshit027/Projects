import java.io.*;
import java.awt.*;
import java.net.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;


class Console extends JFrame implements ActionListener
{
	static JPanel center,north,south;
	JLabel headerLB;
	JButton startTestB,endTestB,nextB1;
	CardLayout cards=new CardLayout();
	ImagePanel imgPnl;
	TestPanel testPnl;
	InstructionPanel insPnl;
    static String testdata[][];
    int score;


	Console()
	{
		setSize(800,600);
		setLayout(new BorderLayout(30,80));

		north=new JPanel();
		north.setLayout(new FlowLayout(FlowLayout.CENTER));
		headerLB=new JLabel("Test");
		headerLB.setFont(new Font("Verdana",Font.BOLD,40));
		north.add(headerLB);
		getContentPane().add(north,"North");

		insPnl=new InstructionPanel();
		testPnl=new TestPanel();
		imgPnl=new ImagePanel();


		center=new JPanel();
		center.setLayout(cards);
		center.add(imgPnl,"imagePanel");
		center.add(testPnl,"testPanel");
		center.add(insPnl,"insPanel");
		getContentPane().add(center,"Center");
		cards.show(center,"imagePanel");

		startTestB=new JButton("Start Test");
		endTestB=new JButton("End Test");
		nextB1=new JButton("Next");

		startTestB.addActionListener(this);
		endTestB.addActionListener(this);
		nextB1.addActionListener(this);

		south=new JPanel();
		south.setLayout(new FlowLayout(FlowLayout.CENTER));

		south.add(startTestB);
		south.add(endTestB);
		south.add(nextB1);
		startTestB.setVisible(false);
		endTestB.setVisible(false);

		add(south,"South");

	    setVisible(true);
	    setResizable(false);
	}

	public static void main(String args[])
	{
		new Console();
	}

	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==nextB1)
		{
			cards.show(center,"insPanel");
			startTestB.setVisible(true);
	    	endTestB.setVisible(true);
	    	nextB1.setVisible(false);
		}


		if(ae.getSource()==startTestB)
		{
			startTestB.setVisible(false);
			cards.show(center,"testPanel");
			 testdata=new String[TestPanel.arrayIndex][6];
			try
			{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				Connection con=DriverManager.getConnection("jdbc:odbc:testdsn");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from test");
				int i=0;
				while(rs.next())
				{
					testdata[i][0]=rs.getString(1);
					testdata[i][1]=rs.getString(2);
					testdata[i][2]=rs.getString(3);
					testdata[i][3]=rs.getString(4);
					testdata[i][4]=rs.getString(5);
					testdata[i][5]=rs.getString(6);
					i++;
				}
				rs.close();
				con.close();
			}
			catch(Exception e)
			{
				e.toString();
			}

			/*for(int i=0;i<TestPanel.arrayIndex;i++)
			{
				for(int j=0;j<6;j++)
				System.out.print(testdata[i][j]+"---");
				System.out.print("\n");
			}*/
            new Timer(this);

		}

		if(ae.getSource()==endTestB)
		{
			endTestB.setVisible(false);
			String correctAnswers[]=new String[TestPanel.arrayIndex];
			try
			{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				Connection con=DriverManager.getConnection("jdbc:odbc:testdsn");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from test");
				int i=0;
				while(rs.next())
				{
					correctAnswers[i]=rs.getString(7);
					i++;
				}
				rs.close();
				con.close();
			}
			catch(Exception e)
			{
				e.toString();
			}
          score=0;
			for(int i=0;i<TestPanel.arrayIndex;i++)
			{
				if(TestPanel.answers[i].equals(correctAnswers[i]))
			    score=score+1;
			    //System.out.println(TestPanel.answers[i]+"--"+correctAnswers[i]);
			}

			Timer.minutes=2;
			TestPanel.timer.setVisible(false);
			TestPanel.questionLB.setVisible(false);
			JOptionPane.showMessageDialog(this,"You Scored "+this.score+" out of "+TestPanel.arrayIndex);
		}
	}
}

class ImagePanel extends JPanel                                        //ImagePanel
{
	ImageIcon image;
	JLabel imageLabel;
	ImagePanel()
	{
		setLayout(new BorderLayout(10,10));
	    image=new ImageIcon("window.jpg");
	    imageLabel=new JLabel(image,JLabel.CENTER);
	    add(imageLabel,"Center");
	}
}

class TestPanel extends JPanel implements ActionListener       //TestPanel
{
	static JLabel questionLB;
	static JRadioButton op1,op2,op3,op4;
	static JButton submitB,nextB;
	ButtonGroup grp;
	JPanel center,north,south;
     int counter=0;
     static String answers[]=null;
     static int arrayIndex;
     static JLabel timer;


	TestPanel()
	{
		setLayout(new BorderLayout());

		center=new JPanel();
		center.setLayout(new BorderLayout(20,20));

		JPanel center1=new JPanel();
		center1.setLayout(new FlowLayout(FlowLayout.RIGHT));
        timer=new JLabel("00:00");
        timer.setFont(new Font("Verdana",0,20));
        center1.add(timer);
		center.add(center1,"North");


		JPanel center2=new JPanel();
		center2.setLayout(new GridLayout(5,1));
        questionLB=new JLabel("Press next to continue : -");
        questionLB.setFont(new Font("Verdana",0,20));
        questionLB.setForeground(Color.red);

		op1=new JRadioButton("");
		op2=new JRadioButton("");
		op3=new JRadioButton("");
		op4=new JRadioButton("");

		op1.setFont(new Font("Verdana",0,20));
		op2.setFont(new Font("Verdana",0,20));
		op3.setFont(new Font("Verdana",0,20));
		op4.setFont(new Font("Verdana",0,20));

		op1.setVisible(false);
		op2.setVisible(false);
		op3.setVisible(false);
		op4.setVisible(false);
		op1.setBackground(Color.blue);
		op1.setForeground(Color.white);
		op2.setBackground(Color.blue);
		op2.setForeground(Color.white);
		op3.setBackground(Color.blue);
		op3.setForeground(Color.white);
		op4.setBackground(Color.blue);
		op4.setForeground(Color.white);

		grp=new ButtonGroup();

		grp.add(op1);
		grp.add(op2);
		grp.add(op3);
		grp.add(op4);

        center2.add(questionLB);
		center2.add(op1);
		center2.add(op2);
		center2.add(op3);
		center2.add(op4);

		op1.addActionListener(this);
		op2.addActionListener(this);
		op3.addActionListener(this);
		op4.addActionListener(this);

		center.add(center2,"Center");
		center1. setBackground(Color.yellow);
   		center1. setForeground(Color.black);

		add(center,"Center");

		south=new JPanel();
		south.setLayout(new FlowLayout(FlowLayout.CENTER));
		submitB=new JButton("Submit");
		nextB=new JButton("Next");

		submitB.addActionListener(this);
		submitB.setVisible(false);
		nextB.addActionListener(this);

		south.add(submitB);
		south.add(nextB);
		add(south,"South");

        //intializing the array

        arrayIndex=0;
        try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con=DriverManager.getConnection("jdbc:odbc:testdsn");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from test");

			while(rs.next())
			{
				arrayIndex+=1;
			}
			rs.close();
			con.close();
		}
		catch(Exception e)
		{
			e.toString();
		}
		answers=new String[TestPanel.arrayIndex];
        for(int i=0;i<TestPanel.arrayIndex;i++)
		answers[i]="ffffffffff";
	}

	public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==nextB)
			{
				op1.setVisible(true);
				op2.setVisible(true);
				op3.setVisible(true);
				op4.setVisible(true);
				submitB.setEnabled(false);
                submitB.setVisible(true);

				questionLB.setText("Q "+Console.testdata[counter][0]+" : - "+Console.testdata[counter][1]);
				op1.setText(Console.testdata[counter][2]);
				op2.setText(Console.testdata[counter][3]);
				op3.setText(Console.testdata[counter][4]);
				op4.setText(Console.testdata[counter][5]);
                counter++;

				grp.clearSelection();
                nextB.setEnabled(false);



			}

			else if(ae.getSource()==submitB)
			{
				if(op1.isSelected()==true)
				answers[this.counter-1]=op1.getText();
				else
				if(op2.isSelected()==true)
				answers[this.counter-1]=op2.getText();
				else
				if(op3.isSelected()==true)
				answers[this.counter-1]=op3.getText();
				else
				if(op4.isSelected()==true)
				answers[this.counter-1]=op4.getText();

               nextB.setEnabled(true);
               submitB.setEnabled(false);
				if(counter-1==TestPanel.arrayIndex-1)
				{
						nextB.setVisible(false);
						submitB.setVisible(false);
						questionLB.setText("Thank You !! Press End Test.");
						//for(int i=0;i<TestPanel.arrayIndex;i++)
						//{
						//	System.out.println(answers[i]);
						//}

						op1.setVisible(false);
						op2.setVisible(false);
						op3.setVisible(false);
                		op4.setVisible(false);
				}

			}

			if(ae.getSource()==op1)
			{
				submitB.setEnabled(true);
			}
			else if(ae.getSource()==op2)
			{
				submitB.setEnabled(true);
			}
			else if(ae.getSource()==op3)
			{
				submitB.setEnabled(true);
			}
			else if(ae.getSource()==op4)
			{
				submitB.setEnabled(true);
			}
	}

}


class InstructionPanel extends JPanel                                           //InstructionPanel
{
	JPanel north,center ,south;

	JLabel headerLB,in1,in2,in3;

	InstructionPanel ()
	{
		setLayout(new BorderLayout(0,40));
		north=new JPanel();
		north.setLayout(new FlowLayout(FlowLayout.CENTER));
		headerLB=new JLabel("Instructions");
		headerLB.setFont(new Font("Verdana",0,20));
		north.add(headerLB);
		add(north,"North");

		center=new JPanel();
		center.setLayout(new GridLayout(3,1));
		in1=new JLabel("1 : Number of questions is 10");
		in2=new JLabel("2 : Weight of each question is 1");
		in3=new  JLabel("3 : Available time is 2 minutes ");

		in1.setFont(new Font("Verdana",0,20));
		in2.setFont(new Font("Verdana",0,20));
		in3.setFont(new Font("Verdana",0,20));

		center.add(in1);
		center.add(in2);
		center.add(in3);
		add(center,"Center");


	}


}

class Timer extends Thread
{

	static int minutes ,seconds;
	Console ref;
	Timer(Console ref)
	{
		minutes=0;
		seconds=0;
		ref=this.ref;
		start();
	}

	public void run()
	{
		while(true)
		{
			seconds+=1;
			if(seconds==59)
			{
				minutes+=1;
				seconds=0;
			}
			TestPanel.timer.setText(minutes+":"+seconds);
			try
			{
				sleep(1000);
			}
			catch(Exception e)
			{
				e.toString();
			}
			if(minutes==2)
			{
				TestPanel.timer.setText("Time Out");
				TestPanel.questionLB.setText("Thank You !! Press End Test. ");
				TestPanel.submitB.setVisible(false);
				TestPanel.nextB.setVisible(false);
				TestPanel.op1.setVisible(false);
				TestPanel.op2.setVisible(false);
				TestPanel.op3.setVisible(false);
				TestPanel.op4.setVisible(false);
				break;
			}
		}
	}
}