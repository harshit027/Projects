import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class StudentManagement extends JFrame implements ActionListener{
	JPanel topPanel = new JPanel();
	JPanel bottomPanel = new JPanel();
	JPanel centerPanel = new JPanel();
	JLabel lblHeader = new JLabel("S T U D E N T   M A N A G M E N T   S Y S T E M");
	JButton btnRegister, btnLogin;
	JLabel loggedinUser = new JLabel ("");
	boolean validUser =false;
	StudentManagement() {
		setSize(700,500);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().setBackground(Color.orange);
		setBackground(Color.white);
		lblHeader.setFont(new Font("Arial",Font.BOLD, 26));
		topPanel.add(lblHeader);
		getContentPane().add(topPanel,"North");
		btnRegister = new JButton("Register");
		btnLogin = new JButton("Login");
		bottomPanel.setLayout(new FlowLayout());
		bottomPanel.add(btnRegister);
		bottomPanel.add(btnLogin);
		bottomPanel.add(loggedinUser);
		topPanel.setBackground(Color.orange);
		bottomPanel.setBackground(Color.orange);
		centerPanel.setBackground(Color.orange);
		centerPanel.add(new JLabel(new ImageIcon("headerphoto.jpg")));
		getContentPane().add(bottomPanel,"South");
		getContentPane().add(centerPanel,"Center");
		btnRegister.addActionListener(this);
		btnLogin.addActionListener(this);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource() == btnRegister) {
			new RegistrationForm(this);
		}
		if(ae.getSource() == btnLogin) {
			if(validUser == false) {
				new LoginForm(this);
			}
		}
	}
	public Insets getInsets() {
		return new Insets(50,50,50,50);
	}
	public static void main(String args[]) {
		new StudentManagement();
	}
}

class LoginForm extends JFrame implements ActionListener{
	JPanel topPanel = new JPanel();
	JPanel bottomPanel = new JPanel();
	JPanel centerPanel = new JPanel();
	JLabel lblHeader = new JLabel("L O G I N   F O R M");
	JButton btnLogin, btnReset, btnBack;
	JTextField tfUsername = new JTextField();
	JPasswordField pfPassword = new JPasswordField();
	JLabel lblUsername = new JLabel("Username", JLabel.RIGHT);
	JLabel lblPassword = new JLabel ("Password",JLabel.RIGHT);
	boolean validUser =false;
	StudentManagement ref;
	LoginForm(StudentManagement ref) {
		this.ref = ref;
		setSize(400,300);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().setBackground(Color.orange);
		setBackground(Color.white);
		lblHeader.setFont(new Font("Arial",Font.BOLD, 26));
		topPanel.add(lblHeader);
		getContentPane().add(topPanel,"North");
		btnReset = new JButton("Reset");
		btnLogin = new JButton("Login");
		btnBack = new JButton("Back");
		bottomPanel.setLayout(new FlowLayout());
		bottomPanel.add(btnLogin);
		bottomPanel.add(btnReset);
		bottomPanel.add(btnBack);
		topPanel.setBackground(Color.orange);

		bottomPanel.setBackground(Color.orange);
		getContentPane().add(bottomPanel,"South");
		centerPanel.setLayout(new GridLayout(2,2,10,10));
		centerPanel.add(lblUsername);
		centerPanel.add(tfUsername);
		centerPanel.add(lblPassword);
		centerPanel.add(pfPassword);
		centerPanel.setBackground(Color.pink);
		getContentPane().add(centerPanel,"Center");
		btnLogin.addActionListener(this);
		btnReset.addActionListener(this);
		btnBack.addActionListener(this);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource() == btnReset) {
			tfUsername.setText("");
			pfPassword.setText("");
		}
		if(ae.getSource() == btnBack) {
			setVisible(false);
		}
		if(ae.getSource() == btnLogin) {
			try {
				String qry = "select * from students where username='"+tfUsername.getText()+"' and passwd ='"+new String(pfPassword.getPassword())+"'";
				//System.out.println("PACE"+qry);
				Database obj = new Database();
				java.sql.ResultSet rs = obj.getResultSet(qry);
				if(rs.next()) {
					ref.validUser = true;
					ref.loggedinUser.setText("Welcome "+tfUsername.getText());
					setVisible(false);
				}
				else {
					JOptionPane.showMessageDialog(this,"Invalid Username/Password");
				}
			}
			catch(Exception e){
			}
		}
	}
	public Insets getInsets() {
		return new Insets(50,50,50,50);
	}
}

class RegistrationForm extends JFrame implements ActionListener{
	JPanel topPanel = new JPanel();
	JPanel bottomPanel = new JPanel();
	JPanel centerPanel = new JPanel();
	JLabel lblHeader = new JLabel("L O G I N   F O R M");
	JButton btnRegister, btnReset, btnBack;
	JTextField tfUsername = new JTextField();
	JPasswordField pfPassword = new JPasswordField();
	JPasswordField pfRetypePassword = new JPasswordField();
	JTextField tfEmailAddress = new JTextField();
	JLabel lblUsername = new JLabel("Username", JLabel.RIGHT);
	JLabel lblPassword = new JLabel ("Password",JLabel.RIGHT);
	JLabel lblRetypePassword = new JLabel ("Retype Password",JLabel.RIGHT);
	JLabel lblEmailAddress = new JLabel ("Email Address",JLabel.RIGHT);
	boolean validUser =false;
	StudentManagement ref;
	RegistrationForm(StudentManagement ref) {
		this.ref = ref;
		setSize(500,400);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().setBackground(Color.orange);
		setBackground(Color.white);
		lblHeader.setFont(new Font("Arial",Font.BOLD, 26));
		topPanel.add(lblHeader);
		getContentPane().add(topPanel,"North");
		btnReset = new JButton("Reset");
		btnRegister = new JButton("Register");
		btnBack = new JButton("Back");
		bottomPanel.setLayout(new FlowLayout());
		bottomPanel.add(btnRegister);
		bottomPanel.add(btnReset);
		bottomPanel.add(btnBack);
		topPanel.setBackground(Color.orange);

		bottomPanel.setBackground(Color.orange);
		getContentPane().add(bottomPanel,"South");
		centerPanel.setLayout(new GridLayout(4,2,10,10));
		centerPanel.add(lblUsername);
		centerPanel.add(tfUsername);
		centerPanel.add(lblPassword);
		centerPanel.add(pfPassword);
		centerPanel.add(lblRetypePassword);
		centerPanel.add(pfRetypePassword);
		centerPanel.add(lblEmailAddress);
		centerPanel.add(tfEmailAddress);
		centerPanel.setBackground(Color.pink);
		getContentPane().add(centerPanel,"Center");
		btnRegister.addActionListener(this);
		btnReset.addActionListener(this);
		btnBack.addActionListener(this);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource() == btnReset) {
			tfUsername.setText("");
			pfPassword.setText("");
			pfRetypePassword.setText("");
			tfEmailAddress.setText("");
		}
		if(ae.getSource() == btnBack) {
			setVisible(false);
		}
		if(ae.getSource() == btnRegister) {
		}
	}
	public Insets getInsets() {
		return new Insets(50,50,50,50);
	}
}

