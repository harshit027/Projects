//Author: Evren DAGLIOGLU
//email: kozmoz@gmail.com
//Date: 05/25/2005
//Disclaimer:	This code was written for sole amateur purposes. No responsibility will 
//				be taken for the consequences that will arise with the use of this code for
//				commercial use or else. 
//
//				If you like it and want to use it just inform me that I can satisfy my ego.
//				If you find a bug or have a new idea to share with me, you will be welcomed
//				if you contact me...

using System;

using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;

using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Runtime.Remoting.Services;

using ServerClassSpace;
using LinkedList;
using ClientClassSpace;


namespace ServerAppSpace			//Namespace for the Server Application
{
	/// <summary>
	/// Summary description for MsgServer.
	/// </summary>
	class MsgServer : MarshalByRefObject, IServerApp	//IServerApp is the interface for the server application to implement...
														//it will provide necessary methods to interact with the server
	{
		private LinkedList.LinkedList userList = new LinkedList.LinkedList();

		private static int globalPortNo = 10000;			//The first TCP port no that will be send to the client...it will be incremented as new clients logs on.

		private void InvokeClient(string msg, int MsgOrUser, string receiveruser)		//This module calls the related client or clients...it will send them msg info, userlist info or both...
		{
			if (receiveruser == null)		//all users will be notified
			{
				switch (MsgOrUser)
				{
					case 1:			//only message will be send...
					{
						for (userList.Init(); userList.More(); userList.Next())
						{
							ListItem item = userList.GetCurrent();
							string receivermach = userList.ReadItemValue(item);
							string receiverport = userList.ReadItemValue(userList.GotoSubitem(item, 1));


							ClientClass clientobj  = 
								(ClientClass)Activator.GetObject
								(
								typeof(ClientClass),
								"tcp://" + receivermach + ":" + receiverport + "/TcpClient"		//====>>>> Portno here
								);

					
							clientobj.UpdateClient(msg, null, 1);
						}

						break;
					}
					case 2:			//only userlist will be sent....because the userlist is a shared data among all clients, it will always be sent to all of the clients.
					{
						string usernamestring = "";
						for (userList.Init(); userList.More(); userList.Next())
						{
							usernamestring += (userList.ReadItemValue(userList.GotoSubitem(userList.GetCurrent(), 2))) + ":" ;
						}

						for (userList.Init(); userList.More(); userList.Next())
						{
							ListItem item = userList.GetCurrent();
							string receivermach = userList.ReadItemValue(item);
							string receiverport = userList.ReadItemValue(userList.GotoSubitem(item, 1));

							ClientClass clientobj  = 
								(ClientClass)Activator.GetObject
								(
								typeof(ClientClass),
								"tcp://" + receivermach + ":" + receiverport + "/TcpClient"		//====>>>> Portno here
								);
					
							clientobj.UpdateClient(null, usernamestring, 2);
						}


						break;
					}
					case 3:			//both message and userlist info will be send....
					{

						string usernamestring = "";	
						for (userList.Init(); userList.More(); userList.Next())			//usernameString is the collection of all usernames separated with ":" 
						{
							usernamestring += (userList.ReadItemValue(userList.GotoSubitem(userList.GetCurrent(), 2))) + ":" ;	//usernames of all online clients are collected here to pass to the client.
						}


						for (userList.Init(); userList.More(); userList.Next())		//iterates through the userList
						{
							ListItem item = userList.GetCurrent();
							string receiverMach = userList.ReadItemValue(item);
							string receiverPort = userList.ReadItemValue(userList.GotoSubitem(item, 1));
//							string dareceiverUser = userList.ReadItemValue(userList.GotoSubitem(item, 2));

							
							ClientClass clientobj  = 
								(ClientClass)Activator.GetObject
								(
								typeof(ClientClass),
								"tcp://" + receiverMach + ":" + receiverPort + "/TcpClient"		//====>>>> Portno here
								);
						
							clientobj.UpdateClient(msg, usernamestring, 3);		//msg is taken as a parameter.
						}

						break;
					}
				}

			}
			else							//message will be sent only to the receiveruser....
			{
				ListItem ptr = userList.SearchSubitem(2, receiveruser); //gets the list adress of the receiver.

				string receivermach = userList.ReadItemValue(ptr);
				string receiverport = userList.ReadItemValue(userList.GotoSubitem(ptr, 1));

				ClientClass clientobj  = 
					(ClientClass)Activator.GetObject
					(
					typeof(ClientClass),
					"tcp://" + receivermach + ":" + receiverport + "/TcpClient"		//====>>>> Portno here
					);
			
				clientobj.UpdateClient(msg, null, 1);
			
			}
		}

		#region IServerApp Implementation
        
		public void RegisterUser(string machinename, string portno, string username)		//registers user to the server
		{

            ListItem item = userList.AddItem(null, 0, machinename);						//adds user to the linked list that i provided... 
			userList.AddItem(item, 3, portno);
			userList.AddItem(item, 3, username);
			

			Console.WriteLine(username + " has logged in");
            
			string tempmsg = username + " has logged in";

			InvokeClient(tempmsg, 3, null);
		}

		public void UnRegisterUser (string machinename, string username)					//unregisters user from the server
		{
			int count = 0;
			
			ListItem ptr = null;
			ptr = userList.SearchSubitem(2, username); //gets the list adress of the receiver.

			if (ptr != null)
				count = userList.DeleteItem(machinename, ptr);

			/*
			for (userList.Init(); userList.More(); userList.Next())
			{
				ListItem item = userList.GetCurrent();
				if (userList.ReadItemValue(item) == machinename)
				{
					username = userList.ReadItemValue(userList.GotoSubitem(item, 2));
                    
					count = userList.DeleteItem(machinename);
				}
				
			}
			*/

			if (count > 0)
				userList.RenumberList(count);
			
			string tempmsg = username + " has logged out";
			Console.WriteLine (tempmsg);

			InvokeClient(tempmsg, 3, null);

		}
		
		public void SendMsg (string sendermachine, string senderusername, string receiverusername, bool isGlobal, string msgString)		//sends message
		{
			if (isGlobal == false)		//to the receiver user only
			{
				msgString = DateTime.Now.ToString() + "\n" + senderusername + ": " + msgString;

				ListItem ptr = userList.SearchSubitem(2, receiverusername); //gets the list adress of the receiver.
				string receiverMach = userList.ReadItemValue(ptr);

			
				InvokeClient(msgString, 1, receiverusername);

			}
			else						//global message...all users will receive the message
			{
				msgString = DateTime.Now.ToString() + "\n" + "(GLOBAL) " + senderusername + ": " + msgString;
				
				InvokeClient(msgString, 1, null);
               
			}

			
		}

		
		public string GetMsgs (string machinename)			//empty method...not used...
		{
            return null;
		}

		public int ServerGivePortNo()						//assigns a port no. for each new client...
		{
			return globalPortNo++;
		}

		public bool UserNameExists (string username)		//checks if the username exists or not
		{
			ListItem ptr = null;
			ptr = userList.SearchSubitem(2, username);		//gets the list adress of the receiver.
            
			if (ptr != null)
				return true;
			
			return false;
		}

		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		public static void Main(string[] args)
		{

			TcpChannel channel = new TcpChannel(9001);
			ChannelServices.RegisterChannel(channel);           
			
			ServerClass remService  = new ServerClass();
			ObjRef obj = RemotingServices.Marshal(remService,"TcpService");
	
			// Create apllications MainForm
			MsgServer frmMain = new MsgServer();

			// provide marshaled object with reference to Application
			remService.theMainServer = ( IServerApp) frmMain;

           
			System.Console.WriteLine("Please press ENTER to exit...");
			System.Console.ReadLine();
	
			// Application closed...

			frmMain.DropClients();

			while (frmMain.userList.IsListEmpty() == false)		//well...this part may arise question marks...when we called DropClients() method, 
																//the clients will logoff the server but if the server closes before the clients loggedoff completely, clients will create exception...
																//so we will wait until all clients logs off...
			{
				;
			}

			RemotingServices.Unmarshal(obj);
			RemotingServices.Disconnect(remService);

		}


		public void DropClients()		//This module will force clients to logout...It will be used if there are online users while the server is closed manually...I haven't dealt with abnormal termination conditions.
		{
			string logoffmsg = "This is an automatic message. Server is closed off, the client will be logged off in a couple of seconds.";
			LinkedList.LinkedList templist = new LinkedList.LinkedList ();

			for (userList.Init(); userList.More(); userList.Next())		//in order to force clients logoff, first i had to copy necessary info to a new list...
			{
				ListItem item = userList.GetCurrent();
				string receiverMach = userList.ReadItemValue(item);
				string receiverPort = userList.ReadItemValue(userList.GotoSubitem(item, 1));

				
				ListItem itemx = templist.AddItem(null, 0, receiverMach);            
				userList.AddItem(itemx, 3, receiverPort);
			}


			for (templist.Init(); templist.More(); templist.Next())		//...now using the templist, the userList can be handled safely...when a user logs off the userList will be modified (user deleted)
																		//...this for () loop is for iteration through the templist...
			{
				ListItem itemz = templist.GetCurrent();

				string machName = templist.ReadItemValue(itemz);
				string port = templist.ReadItemValue(templist.GotoSubitem(itemz, 1));

                				
				ClientClass clientobj  = 
					(ClientClass)Activator.GetObject
					(
					typeof(ClientClass),
					"tcp://" + machName + ":" + port + "/TcpClient"		//====>>>> Portno here
					);
					
				clientobj.UpdateClient(logoffmsg, null, 1);				//calls client to update its richtextbox and userlist...
				clientobj.LogOffClient();								//forces client to logoff...

			}

		}

		public override Object InitializeLifetimeService()
		{
			// Allow this object to live "forever"
			return null;
		}
	}
}
