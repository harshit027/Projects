using System;

namespace ClientAppSpace
{
	/// <summary>
	/// Summary description for IClientApp.
	/// </summary>
	public interface IClientApp
	{
        void ClientUpdate (string msg, string userlistUpdated, int MsgOrUser);
		void AutoLogOff ();
	}
}
