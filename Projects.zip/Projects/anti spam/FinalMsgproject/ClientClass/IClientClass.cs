using System;
using ClientAppSpace;

namespace ClientClassSpace
{
	/// <summary>
	/// Summary description for IClientClass.
	/// </summary>
	public interface IClientClass
	{
		void UpdateClient (string msg, string userlistUpdated, int MsgOrUser);
		void LogOffClient ();
	}
}
