using System;

using ClientAppSpace;
using System.Runtime.InteropServices;



namespace ClientClassSpace
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	/// 
	

	public class ClientClass : MarshalByRefObject, IClientClass			//Client side programming....
	{
		private IClientApp theClient = null;


		public IClientApp theMainClient
		{
			set
			{
				theClient = value;
			}
		}

		//these functions are used for transferring the response of the server to the clients...

		public void UpdateClient (string msg, string userlistUpdated, int MsgOrUser)
		{
			theClient.ClientUpdate (msg, userlistUpdated, MsgOrUser);
		}

		public void LogOffClient()
		{
			theClient.AutoLogOff();
		}

		public override Object InitializeLifetimeService()
		{
			// Allow this object to live "forever"
			return null;
		}


	}
}
