using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Runtime.Remoting.Services;
using System.Threading;

using ServerClassSpace;
using ClientClassSpace;

namespace ClientAppSpace
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class ClientApp : System.Windows.Forms.Form, IClientApp
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;

	
		private static ServerClass SObj = null;
		private static int portno = 0;
		private System.Windows.Forms.RichTextBox messageBox;
		private System.Windows.Forms.ListBox usersList;
		private System.Windows.Forms.TextBox messageEntryBox;
		private System.Windows.Forms.TextBox serverName;
		private System.Windows.Forms.TextBox userName;
		private System.Windows.Forms.Button btnLogon;
		private System.Windows.Forms.Button btnLogoff;
		private System.Windows.Forms.Button btnSendMsg;
		private System.Windows.Forms.Button btnCross;
		private System.Windows.Forms.CheckBox checkGlobal;


		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ClientApp()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

			messageEntryBox.KeyPress += new KeyPressEventHandler(PressAnyKey);		//for capturing "Enter" key when pressed in the message entry box...

		}

		public void ClientUpdate (string msg, string userlistUpdated, int MsgOrUser)		//this module will update the message list or userslist of the client...it will be trigged by the server...
		{
			switch (MsgOrUser)
			{
				case 1:				//new message
				{
					if (messageBox.Text.Length == 0)
						messageBox.AppendText(msg);
					else
						messageBox.AppendText("\n" + msg);

					break;
				}
				case 2:				//new users
				{
                    usersList.Items.Clear();

					if (userlistUpdated.Length == 0)
						return;
		
					int ix = userlistUpdated.IndexOf(':');

					if (ix != -1)
					{
						while (userlistUpdated.IndexOf(':') != -1)
						{
							string temp = userlistUpdated.Substring(0, userlistUpdated.IndexOf(':')+1);
							temp = temp.Remove(temp.Length-1, 1);
							if (temp != null || temp.Length > 0)
								usersList.Items.Add(temp);

							userlistUpdated = userlistUpdated.Remove(0, userlistUpdated.IndexOf(':')+1);
						}
					}

					break;
				}
				case 3:				//all (message and userlist)
				{
					if (messageBox.Text.Length == 0)
						messageBox.AppendText(msg);
					else
						messageBox.AppendText("\n" + msg);


					usersList.Items.Clear();

					if (userlistUpdated.Length == 0)
						return;
		
					int ix = userlistUpdated.IndexOf(':');

					if (ix != -1)		//this section parses userliststring...
					{
						while (userlistUpdated.IndexOf(':') != -1)
						{
							string temp = userlistUpdated.Substring(0, userlistUpdated.IndexOf(':')+1);
							temp = temp.Remove(temp.Length-1, 1);
							if (temp != null || temp.Length > 0)
								usersList.Items.Add(temp);

							userlistUpdated = userlistUpdated.Remove(0, userlistUpdated.IndexOf(':')+1);
						}
					}

					break;
				}
			}
			messageBox.Focus();
			messageBox.ScrollToCaret();
		}


		public void AutoLogOff()
		{
			string msg = "Server is shut down...";

			if (messageBox.Text.Length == 0)
				messageBox.AppendText(msg);
			else
				messageBox.AppendText("\n" + msg);

           
            SObj.Logoff(System.Environment.MachineName, userName.Text);

			usersList.Items.Clear();

			btnLogon.Enabled = true;
			btnLogoff.Enabled = false;
			btnSendMsg.Enabled = false;

			serverName.Enabled = true;
			userName.Enabled = true;

			SObj = null;

		}

		private void ReinitializeClient()
		{
			string msg = "A Connection problem occured, please try again later...";

			if (messageBox.Text.Length == 0)
				messageBox.AppendText(msg);
			else
				messageBox.AppendText("\n" + msg);

			usersList.Items.Clear();

			btnLogon.Enabled = true;
			btnLogoff.Enabled = false;
			btnSendMsg.Enabled = false;

			serverName.Enabled = true;
			userName.Enabled = true;

			this.Cursor = Cursors.Arrow;
			this.btnLogon.Cursor = Cursors.Hand;
			this.messageBox.Cursor = Cursors.IBeam;
			this.serverName.Cursor = Cursors.IBeam;
			this.userName.Cursor = Cursors.IBeam;
			this.messageEntryBox.Cursor = Cursors.IBeam;
			this.usersList.Cursor = Cursors.Arrow;

			SObj = null;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.messageBox = new System.Windows.Forms.RichTextBox();
			this.btnLogon = new System.Windows.Forms.Button();
			this.btnLogoff = new System.Windows.Forms.Button();
			this.usersList = new System.Windows.Forms.ListBox();
			this.serverName = new System.Windows.Forms.TextBox();
			this.userName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.messageEntryBox = new System.Windows.Forms.TextBox();
			this.btnSendMsg = new System.Windows.Forms.Button();
			this.checkGlobal = new System.Windows.Forms.CheckBox();
			this.btnCross = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// messageBox
			// 
			this.messageBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.messageBox.BackColor = System.Drawing.Color.MistyRose;
			this.messageBox.Location = new System.Drawing.Point(8, 24);
			this.messageBox.Name = "messageBox";
			this.messageBox.ReadOnly = true;
			this.messageBox.Size = new System.Drawing.Size(192, 291);
			this.messageBox.TabIndex = 8;
			this.messageBox.Text = "";
			// 
			// btnLogon
			// 
			this.btnLogon.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnLogon.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnLogon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(162)));
			this.btnLogon.Location = new System.Drawing.Point(208, 291);
			this.btnLogon.Name = "btnLogon";
			this.btnLogon.Size = new System.Drawing.Size(64, 23);
			this.btnLogon.TabIndex = 2;
			this.btnLogon.Text = "Logon";
			this.btnLogon.Click += new System.EventHandler(this.Btn_Logon);
			// 
			// btnLogoff
			// 
			this.btnLogoff.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnLogoff.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnLogoff.Enabled = false;
			this.btnLogoff.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(162)));
			this.btnLogoff.Location = new System.Drawing.Point(288, 291);
			this.btnLogoff.Name = "btnLogoff";
			this.btnLogoff.Size = new System.Drawing.Size(64, 23);
			this.btnLogoff.TabIndex = 7;
			this.btnLogoff.Text = "Logoff";
			this.btnLogoff.Click += new System.EventHandler(this.Btn_Logoff);
			// 
			// usersList
			// 
			this.usersList.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.usersList.BackColor = System.Drawing.Color.MistyRose;
			this.usersList.Cursor = System.Windows.Forms.Cursors.Default;
			this.usersList.Location = new System.Drawing.Point(208, 24);
			this.usersList.Name = "usersList";
			this.usersList.Size = new System.Drawing.Size(144, 186);
			this.usersList.TabIndex = 3;
			// 
			// serverName
			// 
			this.serverName.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.serverName.BackColor = System.Drawing.SystemColors.Info;
			this.serverName.Location = new System.Drawing.Point(272, 227);
			this.serverName.Name = "serverName";
			this.serverName.Size = new System.Drawing.Size(80, 20);
			this.serverName.TabIndex = 0;
			this.serverName.Text = "";
			// 
			// userName
			// 
			this.userName.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.userName.BackColor = System.Drawing.SystemColors.Info;
			this.userName.Location = new System.Drawing.Point(272, 259);
			this.userName.Name = "userName";
			this.userName.Size = new System.Drawing.Size(80, 20);
			this.userName.TabIndex = 1;
			this.userName.Text = "";
			// 
			// label1
			// 
			this.label1.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.label1.Location = new System.Drawing.Point(208, 230);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 16);
			this.label1.TabIndex = 9;
			this.label1.Text = "Server:";
			// 
			// label2
			// 
			this.label2.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.label2.Location = new System.Drawing.Point(208, 263);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(62, 16);
			this.label2.TabIndex = 10;
			this.label2.Text = "Username:";
			// 
			// messageEntryBox
			// 
			this.messageEntryBox.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.messageEntryBox.BackColor = System.Drawing.Color.MistyRose;
			this.messageEntryBox.Location = new System.Drawing.Point(7, 331);
			this.messageEntryBox.Multiline = true;
			this.messageEntryBox.Name = "messageEntryBox";
			this.messageEntryBox.Size = new System.Drawing.Size(262, 64);
			this.messageEntryBox.TabIndex = 4;
			this.messageEntryBox.Text = "<Enter your message here>";
			// 
			// btnSendMsg
			// 
			this.btnSendMsg.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnSendMsg.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnSendMsg.Enabled = false;
			this.btnSendMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(162)));
			this.btnSendMsg.Location = new System.Drawing.Point(277, 331);
			this.btnSendMsg.Name = "btnSendMsg";
			this.btnSendMsg.Size = new System.Drawing.Size(75, 40);
			this.btnSendMsg.TabIndex = 6;
			this.btnSendMsg.Text = "Send Message";
			this.btnSendMsg.Click += new System.EventHandler(this.Btn_SendMsg);
			// 
			// checkGlobal
			// 
			this.checkGlobal.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.checkGlobal.Cursor = System.Windows.Forms.Cursors.Hand;
			this.checkGlobal.Location = new System.Drawing.Point(277, 379);
			this.checkGlobal.Name = "checkGlobal";
			this.checkGlobal.Size = new System.Drawing.Size(75, 24);
			this.checkGlobal.TabIndex = 5;
			this.checkGlobal.Text = "Global";
			// 
			// btnCross
			// 
			this.btnCross.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.btnCross.BackColor = System.Drawing.Color.OrangeRed;
			this.btnCross.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(162)));
			this.btnCross.Location = new System.Drawing.Point(344, 0);
			this.btnCross.Name = "btnCross";
			this.btnCross.Size = new System.Drawing.Size(16, 16);
			this.btnCross.TabIndex = 11;
			this.btnCross.Text = "X";
			this.btnCross.Click += new System.EventHandler(this.Btn_CloseForm);
			// 
			// label3
			// 
			this.label3.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.label3.BackColor = System.Drawing.Color.OrangeRed;
			this.label3.Cursor = System.Windows.Forms.Cursors.SizeAll;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(162)));
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(344, 16);
			this.label3.TabIndex = 12;
			this.label3.Text = "Messenger X";
			this.label3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.MouseUp);
			this.label3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MouseMove);
			this.label3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MouseDown);
			// 
			// ClientApp
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.DarkOrange;
			this.ClientSize = new System.Drawing.Size(360, 408);
			this.ControlBox = false;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label3,
																		  this.btnCross,
																		  this.checkGlobal,
																		  this.btnSendMsg,
																		  this.messageEntryBox,
																		  this.label2,
																		  this.label1,
																		  this.userName,
																		  this.serverName,
																		  this.usersList,
																		  this.btnLogoff,
																		  this.btnLogon,
																		  this.messageBox});
			this.Name = "ClientApp";
			this.Opacity = 0.75;
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PressAnyKey);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{

//			TcpChannel channel = new TcpChannel(9003);
			
//			ChannelServices.RegisterChannel(channel);           
			
			ClientClass remService  = new ClientClass();
			ObjRef obj = RemotingServices.Marshal(remService,"TcpClient");
	
			// Create apllications MainForm
			ClientApp frmMain = new ClientApp();

			// provide marshaled object with reference to Application
			remService.theMainClient = ( IClientApp) frmMain;

			System.Console.WriteLine("Please press ENTER to exit...");
			System.Console.ReadLine();		
	

			// Application closed...

			Application.Run(frmMain);

            
			RemotingServices.Unmarshal(obj);
			RemotingServices.Disconnect(remService);

		}

		private bool CheckObjValidity()
		{
			try
			{
				ServerClass clientobj  = 
					(ServerClass)Activator.GetObject
					(
					typeof(ServerClass),
					"tcp://" + serverName.Text + ":9001/TcpService"
					);

			}
			catch (RemotingException e)
			{
				
				MessageBox.Show("Connection to server is lost...Try to Logon again...");
				return false;
			}
			catch (ArgumentNullException ef)
			{
				MessageBox.Show("Cannot connect to server...Try to Logon again...");
				return false;
			}
			catch (Exception exc)
			{
                MessageBox.Show(exc.Message);
				return false;
			}

			return true;

		}

		private void Btn_Logon(object sender, System.EventArgs e)
		{
			if (serverName.Text.Length == 0)
			{
				MessageBox.Show ("Please enter a server name");
				return;
			}

			if (serverName.Text.Length == 0)
			{
				MessageBox.Show ("Please enter a username");
				return;
			}

	//		if (SObj == null)
	//			return;
        
			if (this.CheckObjValidity() == false)
			{
				this.ReinitializeClient();
				return;
			}

			Thread thr = new Thread(new ThreadStart(LogonDlg));
			thr.Start();
	
		}

		void LogonDlg ()
		{
		
			ServerClass clientobj = null;
			btnLogon.Enabled = false;

			try
			{
				clientobj  = 
					(ServerClass)Activator.GetObject
					(
					typeof(ServerClass),
					"tcp://" + serverName.Text + ":9001/TcpService"
					);
				SObj = clientobj;
			
				if (clientobj == null)
				{
					MessageBox.Show("No Active Connection...Please Try Again!");
				}
				else
				{

//					Thread teh = new Thread (new ThreadStart(GetPortNo));
//					teh.Start();

					if (GetPortNo() == false)
						Thread.CurrentThread.Abort();
                    
					this.Cursor = Cursors.WaitCursor;
					this.btnLogon.Cursor = Cursors.WaitCursor;
					this.messageBox.Cursor = Cursors.WaitCursor;
					this.serverName.Cursor = Cursors.WaitCursor;
					this.userName.Cursor = Cursors.WaitCursor;
					this.messageEntryBox.Cursor = Cursors.WaitCursor;
					this.usersList.Cursor = Cursors.WaitCursor;
					
					while (portno == 0)
					{
						;
					}

					this.Cursor = Cursors.Arrow;
					this.btnLogon.Cursor = Cursors.Hand;
					this.messageBox.Cursor = Cursors.IBeam;
					this.serverName.Cursor = Cursors.IBeam;
					this.userName.Cursor = Cursors.IBeam;
					this.messageEntryBox.Cursor = Cursors.IBeam;
					this.usersList.Cursor = Cursors.Arrow;

						
					if (SObj.CanUseThisName(userName.Text) == false)
					{
						SObj.Logon(System.Environment.MachineName, portno.ToString(), userName.Text);

						btnLogoff.Enabled = true;
						btnSendMsg.Enabled = true;

						serverName.Enabled = false;
						userName.Enabled = false;


					}
					else
					{
						MessageBox.Show("Username EXISTS, Please Use ANOTHER Name to Logon");
						btnLogon.Enabled = true;
					}

				}

			}
			catch (Exception e)
			{

                MessageBox.Show("Cannot Contact Server, Please Try Again Later");			

			}
		}

		private bool GetPortNo()
		{

			if (SObj == null)
				return false; 

			try
			{
				portno = SObj.GetPortNo();
			
				BinaryServerFormatterSinkProvider serverProv = new BinaryServerFormatterSinkProvider();
				serverProv.TypeFilterLevel = System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;

				BinaryClientFormatterSinkProvider clientProv = new BinaryClientFormatterSinkProvider();

				IDictionary props = new Hashtable();
				props["port"] = portno;
				props["name"] = "";
				//
				TcpChannel channel = new TcpChannel(props, clientProv, serverProv);        
				ChannelServices.RegisterChannel( channel );

				return true;

			}
			catch (Exception e)
			{
				MessageBox.Show(e.Message);
				this.ReinitializeClient();
				return false;
			}
			



//			TcpChannel zchannel = new TcpChannel(portno); 
//			ChannelServices.RegisterChannel(zchannel);   

		}


		private void Btn_Logoff(object sender, System.EventArgs e)
		{
			if (SObj == null)
				return;

			

			Thread thr = new Thread(new ThreadStart(LogOffDlg));
			thr.Start();
		}


		void LogOffDlg ()
		{
			DialogResult result;

			result = MessageBox.Show("Click Yes to LogOff Only; Click No to LogOff and Exit the program or Click Cancel to return back", "LogOff or Exit Completely?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation);
			
			switch (result)
			{
				case DialogResult.Yes:
				{
					try
					{
						SObj.Logoff(System.Environment.MachineName, userName.Text);
					}
					catch (Exception e)
					{
						MessageBox.Show("Abnormal logoff");
					}
			
					usersList.Items.Clear();

					btnLogon.Enabled = true;
					btnLogoff.Enabled = false;
					btnSendMsg.Enabled = false;

					serverName.Enabled = true;
					userName.Enabled = true;

					SObj = null;

					break;
				}
				case DialogResult.No:
				{
					try
					{
						SObj.Logoff(System.Environment.MachineName, userName.Text);
					}
					catch (Exception e)
					{
						MessageBox.Show("Abnormal termination");
					}
			
					usersList.Items.Clear();
                    
					SObj = null;

					this.Close();
					break;
				}
				case DialogResult.Cancel:
				{
					break;
				}
			}
            
			return;
		}


		private void Btn_SendMsg(object sender, System.EventArgs e)
		{

			Thread thr = new Thread(new ThreadStart(SendMsgDlg));
			thr.Start();
		}


		void SendMsgDlg()
		{
			if (this.CheckObjValidity() == false)
				this.ReinitializeClient();
				

			if (checkGlobal.Checked == false)		//private message
			{

				if (usersList.SelectedIndex != -1)
				{
													
					string ownmsg = System.DateTime.Now.ToString() + "\n" +messageEntryBox.Text;

					if (messageBox.Text.Length == 0)
						messageBox.AppendText(ownmsg);
					else
						messageBox.AppendText("\n" + ownmsg);
					
					string user = usersList.GetItemText(usersList.SelectedItem);

					try
					{
						SObj.SendMessage(System.Environment.MachineName, userName.Text, user, false, messageEntryBox.Text);
					}
					catch (Exception e)
					{
                        MessageBox.Show(e.Message);
						this.ReinitializeClient();
					}
					
					

					//MsgPane.Items.Add(DateTime.Now.ToString() + " " + serverName.Text + ": " + MsgBox.Text);
					//MsgBox.Clear();
				}
				else
					MessageBox.Show("Please select a user to send a private message or select global checkbox for global messages");
			}
			else								//global message
			{
							
				string ownmsg = System.DateTime.Now.ToString() + "\n" +messageEntryBox.Text;


				if (messageBox.Text.Length == 0)
					messageBox.AppendText(ownmsg);
				else
					messageBox.AppendText("\n" + ownmsg);



                SObj.SendMessage(System.Environment.MachineName, userName.Text, null, true, messageEntryBox.Text);
			}


			messageBox.Focus();
			messageBox.ScrollToCaret();
			messageEntryBox.Clear();

		}

		private void Btn_CloseForm(object sender, System.EventArgs e)
		{
			if (SObj != null)
			{
				try
				{
					SObj.Logoff(System.Environment.MachineName, userName.Text);
				}
				catch (Exception ez)
				{
					MessageBox.Show("Abnormal termination");
				}
			}

			this.Close();
		}

		public override Object InitializeLifetimeService()
		{
			// Allow this object to live "forever"
			return null;
		}


		#region Captures mouse to move the window to new location 

		// points to hold the current position
		// and the new position for the form and the mouse
		Point MouseCurrrnetPos,MouseNewPos,formPos,formNewPos;
        bool mouseDown=false;

		private void MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			// when the mouse is down we must activate
			// a flag to say that the left button is down
			// and then store the current position
			// of the mouse and the form and we will 
			// use these posotions to calculate the offset
			// that must be added to the loaction
			if(e.Button==MouseButtons.Left)
			{
				mouseDown = true;
				MouseCurrrnetPos = Control.MousePosition;
				formPos = this.Location;
			}
		}

		private void MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if(e.Button==MouseButtons.Left)
				mouseDown=false;		
		}

		private void MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if(mouseDown==true)
			{
				// get the position of the mouse in the screen
				MouseNewPos=Control.MousePosition;

				formNewPos.X=MouseNewPos.X-MouseCurrrnetPos.X+formPos.X;
				formNewPos.Y=MouseNewPos.Y-MouseCurrrnetPos.Y+formPos.Y;

				Location=formNewPos;
				formPos=formNewPos;
				MouseCurrrnetPos=MouseNewPos;
			}
		
		}

		#endregion

		private void PressAnyKey(object sender, System.Windows.Forms.KeyPressEventArgs e)				//for capturing "Enter" key when pressed in the message entry box...
		{
			if (e.KeyChar == (char)13)
			{
				if (messageEntryBox.Text.Length != 0)
				{
					if (SObj != null)
					{
						Thread thr = new Thread(new ThreadStart(SendMsgDlg));
						thr.Start();
					}
				}
				else if (messageEntryBox.Text.Length == 0)
					return;
			}
		}

	}
}
