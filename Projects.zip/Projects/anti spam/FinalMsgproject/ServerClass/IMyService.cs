using System;
using System.Runtime.InteropServices;

namespace ServerClassSpace

{
	/// <summary>
	/// Summary description for IMyService.
	/// </summary>
	/// 
	[Guid("6C007051-4F88-4c45-B66F-C25FE55395C6")]				//well I provided these for Com Interop, but i couldn't managed to achieve my goal...for later use may be...
	[InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
	public interface IMyService
	{
		void Logon (string machinename, string portno, string username);
		void Logoff (string machinename, string username);
		void SendMessage (string sendermachine, string senderusername, string receiverusername, bool isGlobal, string msgString);
		string GetMessage (string machinename);
		int GetPortNo ();
		bool CanUseThisName(string username);
	}
}
