using System;

using System.Collections;
using System.ComponentModel;
using System.Data;


using System.Runtime.InteropServices;
using System.Diagnostics;

using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;


using ServerAppSpace;



namespace ServerClassSpace
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	/// 

	[Guid("F9C4D98D-AD7E-4c16-AC26-12DA6C2D9A4E")]			//well I provided these for Com Interop, but i couldn't managed to achive my goal...for later use may be...
	[ClassInterface(ClassInterfaceType.None)]
	[ProgId("ServerClassSpace.ServerClass")]

	public class ServerClass : MarshalByRefObject, IMyService		//Server class interface implementation...
	{

		private IServerApp theServer = null;				//this will be used to hold the server application's address..


		public IServerApp theMainServer
		{
			set
			{
				theServer = value;
			}
		}

		public override Object InitializeLifetimeService()
		{
			// Allow this object to live "forever"
			return null;
		}



		#region IMyService Implementation		
		//these functions are mainly used for transferring to requests of the clients to the server application...

		public void Logon (string machinename, string portno, string username)
		{
			theServer.RegisterUser(machinename, portno, username);
		}

		public void Logoff (string machinename, string username)
		{
            theServer.UnRegisterUser(machinename, username);
		}

		public void SendMessage (string sendermachine, string senderusername, string receiverusername, bool isGlobal, string msgString)
		{
            theServer.SendMsg(sendermachine, senderusername, receiverusername, isGlobal, msgString);
		}

		public string GetMessage (string machinename)
		{
            return theServer.GetMsgs(machinename);
		}

		public int GetPortNo()
		{
			return theServer.ServerGivePortNo();
		}

		public bool CanUseThisName(string username)
		{
			return theServer.UserNameExists(username);
		}

		#endregion


		public ServerClass()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
