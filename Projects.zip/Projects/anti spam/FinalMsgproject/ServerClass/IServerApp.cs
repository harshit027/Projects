using System;


namespace ServerAppSpace
{
	/// <summary>
	/// Summary description for IServerApp.
	/// </summary>
	public interface IServerApp
	{

        void RegisterUser (string machinename, string portno, string username);
		void UnRegisterUser (string machinename, string username);
		void SendMsg (string sendermachine, string senderusername, string receiverusername, bool isGlobal, string msgString);
		string GetMsgs (string machinename);
		int ServerGivePortNo ();
		bool UserNameExists (string username);

	}
}
