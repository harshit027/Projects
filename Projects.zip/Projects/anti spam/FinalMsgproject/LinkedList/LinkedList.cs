//Author: Evren DAGLIOGLU
//email: kozmoz@gmail.com
//Date: 05/25/2005
//Disclaimer:	This code was written for sole amateur purposes. No responsibility will 
//				be taken for the consequences that will arise with the use of this code for
//				commercial use or else. 
//
//				If you like it and want to use it just inform me that I can satisfy my ego.
//				If you find a bug or have a new idea to share with me, you will be welcomed
//				if you contact me...

//This linked list is created mainly for a tree-like structure...(some kind of tree control)
//with this linkedlist you can create a root item, folder item, document item...and also you can add lines to each item...
//
//Let me try to show you:
//
//	root item1				subitem defn.1		subitem defn2
//		folder item1
//			doc item 1		subitem defn.1		subitem defn2		subitem def3
//			doc item 2
//		folder item2
//	root item2
//
//
//	Well, i'm pretty sure that this coding style isnt a "best-practice"...so you are free to improve it, criticize it, etc.
//	What can be done for example: an hash table may be implemented for quick access to list items...(like CMap usage in c++)
//

using System;

namespace LinkedList
{
	/// <summary>
	/// Summary description for LinkedList.
	/// </summary>
	
	public class ListItem
	{
		
		public ListItem hasChild = null;		//points to its first child...
		public ListItem hasParent = null;		//points to its parent; if null this is a root item...
		public ListItem hasLine = null;			//points to its first line item...
		public bool isLastChild = true;

		public ListItem prevSister = null;
		public ListItem nextSister = null;

		public ListItem prevLitem = null;
		public ListItem nextLitem = null;

		//public ListItem lineHead = null; //if (itemtype != 3 && lineHead == null) then (this item is linehead) else if (itemtype == 3 and lineHead != 0) then (this value points to linehead)
		public bool isLineTail = true;

		public System.String itemContent;

		public int sisterIndexNo;
		public int lineIndexNo;

		public sbyte itemType;		//0: rootitem, 1: folderitem, 2: documentitem, 3: subitem
		public int indent = 0;		//multiplier value of the base indentation value (that is 16)
		

	}

	public class LinkedList : ListItem
	{
		public ListItem first, last, current;
	
		
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		
		
		//		static int itemcount = 0;

		public LinkedList()
		{
			first = last = null; 
            			
		}

		public bool IsListEmpty()
		{
			if (first == null && last == null)
				return true;
			
			return false;
		}

		public ListItem AddItem(ListItem parentRef,				//Adds item to the list...
			sbyte itemType, 
			System.String itemContent)
		{

			if (parentRef != null)
				if (parentRef.itemType == 2)	//no subitem can be included under a document type item
					return null;

			ListItem ptr = new ListItem();

			switch (itemType)
			{
				case 0:		//root item
				{
					ptr.itemType = itemType;
					ptr.itemContent = itemContent;
					ptr.hasParent = null;
					ptr.hasChild = null;
					ptr.indent = 0;

					if (first == null && last == null)
					{
						ptr.sisterIndexNo = 1;
						first = last = ptr;
						ptr.prevSister = null;
						ptr.nextSister = null;

						ptr.prevLitem = null;
						ptr.nextLitem = null;
					}

					else
					{
						ptr.sisterIndexNo = last.sisterIndexNo + 1; 
						last.nextSister = ptr;
						ptr.prevSister = last;
						last = ptr;

						ptr.nextSister = null;
					}


					break;
				}
				case 1:		//folder item
				{
					if (parentRef == null)
						return null;

					ptr.itemType = itemType;
					ptr.itemContent = itemContent;
					ptr.hasParent = parentRef;
					ptr.hasChild = null;


					ptr.indent = parentRef.indent + 1;

					if (parentRef.hasChild == null)
					{
						parentRef.hasChild = ptr;
						ptr.sisterIndexNo = 1;
						ptr.isLastChild = true;
                        
						ptr.prevSister = null;
						ptr.nextSister = null;

						ptr.prevLitem = null;
						ptr.nextLitem = null;
					}

					else
					{
						ListItem temp = parentRef.hasChild;

						while (ptr != null)
						{
							if (temp.isLastChild == true)
								break;
							else
								temp = temp.nextSister;
									
						}

						temp.isLastChild = false;
						ptr.isLastChild = true;
                        
						ptr.sisterIndexNo = temp.sisterIndexNo + 1;
												
						temp.nextSister = ptr;
						ptr.prevSister = temp;
						ptr.nextSister = null;

					}


					break;
				}
				case 2:		//document item
				{
					if (parentRef.itemType == 0 || parentRef == null)
						return null;

					ptr.itemType = itemType;
					ptr.itemContent = itemContent;
					ptr.hasParent = parentRef;
					ptr.hasChild = null;


					ptr.indent = parentRef.indent + 1;

					if (parentRef.hasChild == null)
					{
						parentRef.hasChild = ptr;
						ptr.sisterIndexNo = 1;
						ptr.isLastChild = true;
                        
						ptr.prevSister = null;
						ptr.nextSister = null;

						ptr.prevLitem = null;
						ptr.nextLitem = null;
					}

					else
					{
						ListItem temp = parentRef.hasChild;

						while (ptr != null)
						{
							if (temp.isLastChild == true)
								break;
							else
								temp = temp.nextSister;
									
						}

						temp.isLastChild = false;
						ptr.isLastChild = true;
                        
						ptr.sisterIndexNo = temp.sisterIndexNo + 1;
												
						temp.nextSister = ptr;
						ptr.prevSister = temp;
						ptr.nextSister = null;

					}

					break;
				}
				case 3:		//subitem item
				{
					if (parentRef == null)
						return null;

					ptr.itemType = itemType;
					ptr.itemContent = itemContent;
					ptr.hasParent = parentRef;
					ptr.hasChild = null;

					if (parentRef.hasLine == null)
					{
						parentRef.hasLine = ptr;

						ptr.isLineTail = true;
						ptr.prevLitem = null;
						ptr.nextLitem = null;
						ptr.lineIndexNo = 1;

					}
					else
					{
						ListItem temp = parentRef.hasLine;

						while (ptr != null)
						{
							if (temp.isLineTail == true)
								break;
							else
								temp = temp.nextLitem;
									
						}

						temp.isLineTail = false;
						ptr.isLineTail = true;

						ptr.lineIndexNo = temp.lineIndexNo + 1;
						
						temp.nextLitem = ptr;
						ptr.prevLitem = temp;
						ptr.nextLitem = null;
						

					}	

					break;
				}
			}

			return ptr;
				
		}

		
		public ListItem FindItem (string str)		//well this module will work correct only if the item value is unique...a better approach should be developed.
		{
			
			ListItem ptr = first;

			while (ptr != null)
			{
				if (ptr.itemContent == str)
				{
					return ptr;
					
				}
				ptr = ptr.nextSister;
			}
			

			return null;
		}
        
		public ListItem SearchSubitem(int subno, string searchstring)		//this module searches through the given sub no of the items...the ptr of the main item will be returned...
		{
			ListItem ptr = first;

			while (ptr != null)
			{
				if (ptr.hasLine != null)
				{
					ListItem sptr = GotoSubitem(ptr, 2);
					if (sptr != null)
					{
						if (sptr.itemContent == searchstring)
							return ptr;
					}
				}

				ptr = ptr.nextSister;
			}
			

			return null;
            
		}
		
		
		public ListItem GotoSubitem (ListItem item, int subno)
		{
			if (item.hasLine != null)
			{
				ListItem ptr = item.hasLine;

				while (ptr != null)
				{
					if (ptr.lineIndexNo == subno)
						return ptr;
					ptr = ptr.nextLitem;													
				}                			

			}
			
			return null;
            
		}

		
		public string ReadItemValue (ListItem item)		//returns the content of the item...
		{
			return item.itemContent;
		}


		public int DeleteItem(System.String content, ListItem deletedptr)	//works on main items only...you cannot delete one subitem, you have to delete all row with this command...
			//if you want to change value of a subitem use my  ChangeContent(ListItem ptr, string newval) module...
		{
			//int newcount = last.sisterIndexNo - 1;

			ListItem ptr = first;

			while (ptr != null)
			{
				if (ptr.itemContent == content && ptr == deletedptr)
				{
					if (ptr == first && ptr == last)
					{
						first = last = ptr = null;
						
					}
					else if (ptr == first)
					{
						ListItem temp = ptr.nextSister;
						first = temp;
						temp.prevSister = null;

					}
					else if (ptr == last)
					{
						ListItem temp = ptr.prevSister;
						last = temp;
						temp.nextSister = null;
					}
					else
					{
						ListItem temp1 = ptr.prevSister;
						ListItem temp2 = ptr.nextSister;
						temp1.nextSister = temp2;
						temp2.prevSister = temp1;
					}

					//RenumberList(newcount);

					break;
				}
				

				ptr = ptr.nextSister;
			}

			if (last != null)
				return (last.sisterIndexNo - 1);
			
			return 0;

		}

		
		public void RenumberList(int count)			
		{
			if (count != 0 && first != null && last != null)
			{
				ListItem ptr = first;
				int ix = 1;
				while (ptr != null && ix++ <= count)
				{
					ptr.sisterIndexNo = ix;
					ptr = ptr.nextSister;
				}
			}
		}

		public void ChangeContent(ListItem ptr, string newval)		//changes the content of the given item...
		{
			ptr.itemContent = newval;
		}
	
		
		public void DisplayList()
		{
			
			ListItem ptr = first;

			while (ptr != null)
			{
				Console.WriteLine("Item no {0} is {1}", ptr.lineIndexNo, ptr.itemContent);

				ptr = ptr.nextSister;
			}
			//		if (itemcount == 0)
			//			Console.WriteLine("There is no item to display...List is empty");
				
		}
		

		//These Init(), More(), Next() and GetCurrent() modules are used together in a For (;;) structure to iterate through the list...
		//
		//for (Init(); More(); Next())
		//{
        //	Listitem ptr = list.GetCurrent();
		//
		//	...
		//}

		public void Init ()
		{
			current = first;
		}

		public bool More ()
		{
            if (current != null)
				return true;
			return false;
		}

		public void Next ()
		{
			current = current.nextSister;
		}

		public ListItem GetCurrent ()
		{
			return current;
		}
	}
}