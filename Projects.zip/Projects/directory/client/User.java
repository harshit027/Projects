import java.io.*;
import java.net.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import javax.swing.*;

class User extends JFrame implements ActionListener
{
	public static CardLayout cards=new CardLayout();
	public static JPanel southPanel,northPanel;
	public static JPanel centerPanel;
	JButton newEntryButton,searchButton;
	JLabel heading;
	RegisterPanel registerPnlRef;
	ImagePanel imagePnlRef;
	SearchPanel searchPnlRef;
	static Socket s;
	static BufferedReader in;
	static PrintWriter out;

	static String flag;
	User()
	{
		setSize(600,600);
		setTitle("USER");
		setResizable(false);
		getContentPane().setLayout(new BorderLayout(30,30));
        getContentPane().setBackground(Color.orange);
        northPanel=new JPanel();
		heading=new JLabel("DIRECTORY",JLabel.CENTER);
		heading.setFont(new Font("Verdana",Font.BOLD,40));
		northPanel.add(heading);
		getContentPane().add(northPanel,"North");

		newEntryButton=new JButton("NEW ENTRY");
		searchButton=new JButton("SEARCH");
		newEntryButton.addActionListener(this);
		searchButton.addActionListener(this);
		southPanel=new JPanel();
		southPanel.setLayout(new FlowLayout());
		southPanel.add(newEntryButton);
		southPanel.add(searchButton);
		getContentPane().add(southPanel,"South");

		registerPnlRef=new RegisterPanel();
		imagePnlRef=new ImagePanel();
		searchPnlRef=new SearchPanel();

		centerPanel=new JPanel();
		centerPanel.setLayout(cards);
	    centerPanel.add(imagePnlRef,"ImagePanel");
	    centerPanel.add(registerPnlRef,"RegisterPanel");
	    centerPanel.add(searchPnlRef,"SearchPanel");
	    getContentPane().add(centerPanel,"Center");
	    cards.show(centerPanel,"ImagePanel");

		setVisible(true);
		/************SocketCode*************/
		try
		{
			s=new Socket("localhost",3400);
			in=new BufferedReader(new InputStreamReader(s.getInputStream()));
		    out=new PrintWriter(s.getOutputStream(),true);
		    System.out.println(in.readLine());
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		/***************************************/
	}

	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==searchButton)
		{
			this.cards.show(centerPanel,"SearchPanel");
		}
		if(ae.getSource()==newEntryButton)
		{
			this.cards.show(centerPanel,"RegisterPanel");
		}
	}

	public static void main(String args[])
	{
		new User();
	}
}

class ImagePanel extends JPanel
{
	ImageIcon image;
	JLabel imageLabel;
	ImagePanel()
	{
		setLayout(new BorderLayout(10,10));
	    image=new ImageIcon("abt1.jpg");
	    imageLabel=new JLabel(image,JLabel.CENTER);
	    add(imageLabel,"Center");
	}
}

class RegisterPanel extends JPanel implements ActionListener
{
	JPanel centerPanel,southPanel;
	JButton registerButton;
	JTextField nameTF,phoneTF,mobileTF;
	JTextArea addressTA;
	JLabel nameLB,phoneLB,mobileLB,addressLB,sexLB;
	JComboBox sexCB;
    ImagePanel imgPnl;
    ImageIcon image;
    static Socket s;
	static BufferedReader in;
	static PrintWriter out;

	RegisterPanel()
	{
		setLayout(new BorderLayout(0,10));
		JLabel heading=new JLabel("REGISTRATION",JLabel.CENTER);
		heading.setFont(new Font("Verdana",Font.BOLD,20));
		add(heading,"North");

		centerPanel=new JPanel();
		centerPanel.setLayout(new GridLayout(6,3,0,30));
		nameLB=new JLabel("Name");
		phoneLB=new JLabel("Phone");
		mobileLB=new JLabel("Mobile");
		addressLB=new JLabel("Address");
		sexLB=new JLabel("Sex");


		nameTF=new JTextField(20);
		phoneTF=new JTextField(20);
		mobileTF=new JTextField(20);
		addressTA=new JTextArea();

		sexCB=new JComboBox();
		sexCB.addItem("MALE");
		sexCB.addItem("FEMALE");

		centerPanel.add(nameLB);
		centerPanel.add(nameTF);
		centerPanel.add(phoneLB);
		centerPanel.add(phoneTF);
		centerPanel.add(mobileLB);
		centerPanel.add(mobileTF);
		centerPanel.add(addressLB);
		centerPanel.add(addressTA);
		centerPanel.add(sexLB);
		centerPanel.add(sexCB);
		add(centerPanel,"Center");

		southPanel=new JPanel();
		southPanel.setLayout(new FlowLayout());
		registerButton=new JButton("REGISTER");
		registerButton.addActionListener(this);
		southPanel.add(registerButton);
		add(southPanel,"South");

		image=new ImageIcon("MSN.jpg");
		JLabel imgLabel=new JLabel(image,JLabel.CENTER);
		add(imgLabel,"East");

	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==registerButton)
		{
			try
			{
				User.flag="register";
				User.out.println(User.flag);
				String entriesToServer[]=new String[5];
				entriesToServer[0]=this.nameTF.getText();
				entriesToServer[1]=this.phoneTF.getText();
				entriesToServer[2]=this.mobileTF.getText();
				entriesToServer[3]=this.addressTA.getText();
				entriesToServer[4]=this.sexCB.getSelectedItem()+"";
				for(int i=0;i<5;i++)
				{
					User.out.println(entriesToServer[i]);
				}
				JOptionPane.showMessageDialog(this,User.in.readLine());

			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}

	}
}

class SearchPanel extends JPanel implements ActionListener
{
	JPanel centerPanel;
	JButton searchBtn;
	JLabel heading,nameLB;
	static JTextField nameTF;
	ImageIcon image;

	SearchPanel()
	{
		setLayout(new BorderLayout(20,10));

		heading=new JLabel("SEARCH",JLabel.CENTER);
		heading.setFont(new Font("Verdana",Font.BOLD,20));
		add(heading,"North");

		centerPanel=new JPanel();
		centerPanel.setLayout(new FlowLayout(FlowLayout.LEFT,30,80));
		nameLB=new JLabel("Name");
		nameTF=new JTextField(20);
        searchBtn=new JButton("SEARCH");
        searchBtn.addActionListener(this);
        JLabel temp=new JLabel("                          ");
		centerPanel.add(nameLB);
		centerPanel.add(nameTF);
		centerPanel.add(temp);
		centerPanel.add(searchBtn);

		add(centerPanel,"Center");

		image=new ImageIcon("PID.jpg");
		JLabel imgLabel=new JLabel(image,JLabel.CENTER);
		add(imgLabel,"East");
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==searchBtn)
		{
			new SearchResultFrame();
		}
	}
}

class SearchResultFrame extends JFrame
{
	JTable table;
	String heads[]={"User ID","Username","Phone","Mobile","Address","Sex"};
	String data[][];
	SearchResultFrame()
	{
		setSize(500,500);
		setTitle("Search Result");
        data=new String[1][6];
        try
        {
			User.flag="search";
            User.out.println(User.flag);
		    User.out.println(SearchPanel.nameTF.getText());
		    for(int i=0;i<6;i++)
		    {
		    	//data[0][i]=User.in.readLine();
		    	System.out.println(User.in.readLine());
		    }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
        table=new JTable(data,heads);
        JScrollPane jsp=new JScrollPane(table);
        getContentPane().add(jsp);
        setVisible(true);
	}
}







