import java.sql.*;

public class Database {
	private Connection con=null;
	private Statement st = null;
	private ResultSet rs = null;
	private String dsn=  "pe_6_30PM_2008";
	private String un = "";
	private String pwd="";
	Database() {
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con = DriverManager.getConnection("jdbc:odbc:"+dsn,un, pwd);
		}
		catch(Exception e) {
			//throw e;
		}
	}
	public ResultSet getResultSet(String qry) {
		try {
			st =con.createStatement();
			rs = st.executeQuery(qry);
		}
		catch(Exception e) {
			//throw e;
		}
		return rs;
	}
	public void setData(String qry) {
		try {
			st = con.createStatement();
			st.executeUpdate(qry);
		}
		catch(Exception e) {
		}
	}
}