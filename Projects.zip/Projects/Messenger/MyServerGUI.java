import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

class MyServerGUI extends JFrame implements ActionListener {
	public static void main(String args[]) {
		new MyServerGUI();

	}

        //Menu Variables
	    JMenuBar jmb;
		JMenu smileys,fonts,txtColor,styles;
		JMenuItem smiley1,smiley2,smiley3;
		String fontCaptions[]={"Verdana","Arial","Vrinda","Tahoma","TimesNewRoman"};
		String styleCaptions[]={"Regular","Bold","Italic","Bold Italic"};
		JMenuItem fontStyles[]=null;
		JMenuItem fontTypes[]=null;
		String colorCaptions[]={"Red","Blue","Green","Orange","Yellow","Cyan","Magenta","Black","Pink"};
		Color colorChoice[]={Color.red,Color.blue,Color.green,Color.orange,Color.yellow,Color.cyan,Color.magenta,Color.black,Color.pink};
		JMenuItem colors[]=null;
		String currentFont="Verdana";
	    //------------------------------------

		JTextArea chatArea,writeArea;
		JPanel northPanel,southPanel;
		JButton logoutButton,sendButton;
		Socket s=null;
		ServerSocket ss=null;
		MyServerGUI()
		{
			setSize(500,500);
			setResizable(false);
			setTitle("Server");
			getContentPane().setLayout(new BorderLayout(10,10));
			northPanel=new JPanel();
			northPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
			logoutButton=new JButton("LOGOUT");
			logoutButton.addActionListener(this);
			logoutButton.setBackground(Color.yellow);
			northPanel.add(logoutButton);
			getContentPane().add(northPanel,"North");

			chatArea=new JTextArea(20,40);
			getContentPane().add(new JScrollPane(chatArea),"Center");
			getContentPane().add(chatArea,"Center");
	        getContentPane().add(new JScrollPane(chatArea) ,"Center");

		    southPanel=new JPanel();
			southPanel.setLayout(new BorderLayout(10,10));
			sendButton=new JButton("SEND");
			sendButton.addActionListener(this);
			writeArea=new JTextArea(5,40);
			sendButton.setBackground(Color.yellow);


			southPanel.add(writeArea,"Center");
		    southPanel.add(new JScrollPane(writeArea),"Center");
			southPanel.add(sendButton,"East");
			getContentPane().add(southPanel,"South");
		    getContentPane().setBackground(Color.orange);

		    //MenuCode
		    jmb=new JMenuBar();
			smileys=new JMenu("Smileys");
			fonts=new JMenu("Fonts");
			txtColor=new JMenu("Text Color");
			styles=new JMenu("Styles");
			setJMenuBar(jmb);

			smiley1=new JMenuItem("Smiley1");
			smiley2=new JMenuItem("Smiley2");
			smiley3=new JMenuItem("Smiley3");

			fontStyles=new JMenuItem[4];
			for(int i=0;i<4;i++)
			{
				fontStyles[i]=new JMenuItem(styleCaptions[i]);
				fontStyles[i].addActionListener(this);
				styles.add(fontStyles[i]);
			}
			fontTypes=new JMenuItem[5];
			for(int i=0;i<5;i++)
			{
				fontTypes[i]=new JMenuItem(fontCaptions[i]);
				fontTypes[i].addActionListener(this);
				fonts.add(fontTypes[i]);
			}

		    colors=new JMenuItem[9];
			for(int i=0;i<9;i++)
		    {
				colors[i]=new JMenuItem(colorCaptions[i]);
				colors[i].addActionListener(this);
				txtColor.add(colors[i]);
			}
			smileys.add(smiley1);
			smileys.add(smiley2);
			smileys.add(smiley3);

		    jmb.add(smileys);
			jmb.add(fonts);
			jmb.add(txtColor);
			jmb.add(styles);

        //-----------------------
			setVisible(true);

			try {

						ss = new ServerSocket(3400);
						System.out.println("Server Started");
						s = ss.accept();
                        String message="";
						BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream()));
                        PrintWriter out = new PrintWriter(s.getOutputStream(),true);
                        while(true)
                        {
							message=in.readLine();
							if(message.equalsIgnoreCase("EXIT"))
							{
								out.println("exit");
								break;
							}
							chatArea.setText(chatArea.getText()+"\n "+message);
						}
						s.close();
                        ss.close();
                       chatArea.setText(chatArea.getText()+"\nClosing connections..........");

					}
					catch(Exception e)
					{
						e.toString();
		            }
		}

		public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==logoutButton)
			{
				try
				{
					this.writeArea.setText("exit");
					//this.s.close();
					//this.ss.close();
				}
				catch(Exception e)
				{
					e.toString();
				}
			}
			if(ae.getSource()==sendButton)
		    {
				try
	 	        {
		            PrintWriter out = new PrintWriter(s.getOutputStream(),true);
			        out.println(this.writeArea.getText());
    	            this.chatArea.setText(this.chatArea.getText()+"\nServer : "+this.writeArea.getText());
		  	        this.writeArea.setText("");
		         }

		    catch(Exception e)
		    {
				e.toString();
			}
		}


        for(int i=0;i<4;i++)
		{
			if(ae.getSource()==fontStyles[i])
			{
				this.writeArea.setFont(new Font(this.currentFont,i,20));
				this.chatArea.setFont(new Font(this.currentFont,i,20));
			}
		}
		for(int i=0;i<5;i++)
		{
			if(ae.getSource()==fontTypes[i])
			{
				this.writeArea.setFont(new Font(fontCaptions[i],0,20));
				this.chatArea.setFont(new Font(fontCaptions[i],0,20));
				this.currentFont=fontCaptions[i];
			}
		}
		for(int i=0;i<9;i++)
		{
			if(ae.getSource()==colors[i])
		    {
		    	this.writeArea.setForeground(colorChoice[i]);
		    	this.chatArea.setForeground(colorChoice[i]);
		    }
		}
	}
}