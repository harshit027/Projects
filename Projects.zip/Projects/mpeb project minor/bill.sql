-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 29, 2008 at 05:18 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `bill`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `entry`
-- 

CREATE TABLE `entry` (
  `location` varchar(50) NOT NULL,
  `location_code` varchar(50) NOT NULL,
  `bill_mon` varchar(50) NOT NULL,
  `yr` varchar(50) NOT NULL,
  `read_date` varchar(50) NOT NULL,
  `cus_name` varchar(50) NOT NULL,
  `pre_reading` varchar(50) NOT NULL,
  `cus_no` varchar(50) NOT NULL,
  `type_red` char(50) NOT NULL,
  `final_red` varchar(50) NOT NULL,
  `ini_read` varchar(50) NOT NULL,
  `ass` varchar(50) NOT NULL,
  `cur_read` varchar(50) NOT NULL,
  `custn` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `entry`
-- 

INSERT INTO `entry` (`location`, `location_code`, `bill_mon`, `yr`, `read_date`, `cus_name`, `pre_reading`, `cus_no`, `type_red`, `final_red`, `ini_read`, `ass`, `cur_read`, `custn`) VALUES 
('JABALPUR', '01', '12', '', '', 'ANIMESH', '500', '001', '', '', '', '', '', ''),
('INDORE', '02', '', '', '', 'JASHAN', '1000', '002', '', '', '', '', '', '');
