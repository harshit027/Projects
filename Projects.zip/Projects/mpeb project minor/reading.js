function show(el)
   	 {
       if (el.value == "3")
       {
		   
         document.getElementById("final_red").style.display = "inline";
       }
       else
       {
         document.getElementById("final_red").style.display = "none";
         
       }
     }
function verify()
{
c_reading=document.getElementById("c_reading").value;
ass=document.getElementById("assessment").value;
custn=document.getElementById("custn").value;
p_reading=document.getElementById("pre_reading").value;
if(document.getElementById("type_read").value=="3")
	{
	i_reading=document.getElementById("i_reading").value;
	f_reading=document.getElementById("f_reading").value;
	diff = f_reading-i_reading;
	result = Number(diff)+Number(ass)+Number(c_reading)-Number(p_reading);	
	}
else result = Number(ass)+Number(c_reading)-Number(p_reading);
if(result == custn) {alert ("verification complete click to continue")	;
document.getElementById("add").disabled=false;
document.getElementById("modify").disabled=false;
document.getElementById("del").disabled=false;
document.getElementById("enquire").disabled=false;
}
else alert ("data entered is incorrect");
}
