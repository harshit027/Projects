var xmlHttp = createXmlHttpRequestObject();
function createXmlHttpRequestObject()
{
var xmlHttp;
try
{
xmlHttp = new XMLHttpRequest();
}
catch(e)
{
var XmlHttpVersions = new Array("MSXML2.XMLHTTP.6.0",
"MSXML2.XMLHTTP.5.0",
"MSXML2.XMLHTTP.4.0",
"MSXML2.XMLHTTP.3.0",
"MSXML2.XMLHTTP",
"Microsoft.XMLHTTP");
// try every prog id until one works
for (var i=0; i<XmlHttpVersions.length && !xmlHttp; i++)
{
try
{
// try to create XMLHttpRequest object
xmlHttp = new ActiveXObject(XmlHttpVersions[i]);
}
catch (e) {}
}
}
if (!xmlHttp)
alert("Error creating the XMLHttpRequest object.");
else
return xmlHttp;
}





function update(textfield1)
{	
if (xmlHttp)
{
try
{
xmlHttp.open("GET", "update.php?value=" + textfield1.value , true);
xmlHttp.onreadystatechange = handleRequestStateChange;
xmlHttp.send(null);
}
// display the error in case of failure
catch (e)
{
alert("Can't connect to server:\n" + e.toString());
}
}
}



function handleRequestStateChange()
{
if(xmlHttp.readyState==3)
  {
   /*busy = document.getElementById("busy");
   newhtml = "<image src = "./indicator.white.gif"/>";
   busy.innerhtml = newhtml;*/
  }
if (xmlHttp.readyState == 4)
{
   /*busy = document.getElementById("busy");
   busy.innerhtml = '<image src = "./indicator.white.gif"/>';*/
if (xmlHttp.status == 200)
{
try
{
handleServerResponse();
}
catch(e)
{
alert("Error reading the response: " + e.toString());
}
}
else
{
// display status message
alert("There was a problem retrieving the data:\n" +
xmlHttp.statusText);
}
}
}



function handleServerResponse()
{
var xmlResponse = xmlHttp.responseXML;
if (!xmlResponse || !xmlResponse.documentElement)
throw("Invalid XML structure:\n" + xmlHttp.responseText);
var rootNodeName = xmlResponse.documentElement.nodeName;
if (rootNodeName == "parsererror") throw("Invalid XML structure");
xmlRoot = xmlResponse.documentElement;
responseText = xmlRoot.firstChild.data;
myDiv = document.getElementById("loc");
myDiv.value = responseText;
}


function update1(textfield1)
{	
if (xmlHttp)
{
try
{
xmlHttp.open("GET", "update.php?value1=" + textfield1.value , true);
xmlHttp.onreadystatechange = handleRequestStateChange1;
xmlHttp.send(null);
}
// display the error in case of failure
catch (e)
{
alert("Can't connect to server:\n" + e.toString());
}
}
}


function handleRequestStateChange1()
{
if(xmlHttp.readyState==3)
  {
   /*busy = document.getElementById("busy");
   newhtml = "<image src = "./indicator.white.gif"/>";
   busy.innerhtml = newhtml;*/
  }
if (xmlHttp.readyState == 4)
{
   /*busy = document.getElementById("busy");
   busy.innerhtml = '<image src = "./indicator.white.gif"/>';*/
if (xmlHttp.status == 200)
{
try
{
handleServerResponse1();
}
catch(e)
{
alert("Error reading the response: " + e.toString());
}
}
else
{
// display status message
alert("There was a problem retrieving the data:\n" +
xmlHttp.statusText);
}
}
}

function handleServerResponse1()
{
var xmlResponse = xmlHttp.responseXML;
if (!xmlResponse || !xmlResponse.documentElement)
throw("Invalid XML structure:\n" + xmlHttp.responseText);
var rootNodeName = xmlResponse.documentElement.nodeName;
if (rootNodeName == "parsererror") throw("Invalid XML structure");
xmlRoot = xmlResponse.documentElement;
cus_name = xmlRoot.getElementsByTagName("cus_name")[0].childNodes[0].nodeValue;

pre_reading = xmlRoot.getElementsByTagName("pre_reading")[0].childNodes[0].nodeValue;

myDiv = document.getElementById("cus_name");
myDiv.value = cus_name;
mydiv = document.getElementById("pre_reading");
mydiv.value = pre_reading; 
}

