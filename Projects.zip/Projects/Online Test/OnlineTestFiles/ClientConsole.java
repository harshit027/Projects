import java.io.*;
import java.awt.*;
import java.net.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.Date;


public class ClientConsole extends JFrame implements ActionListener
{
	CardLayout cards=new CardLayout();
	JPanel center,north,south;
	JLabel headerLB;
	JButton registerB,loginB;
	ImagePanel imgPnlRef;
	RegisterPanel regPnlRef;
	LoginPanel loginPnlRef;
	ClientThread clientThread;

	ClientConsole()
	{
		setSize(400,400);
		setLayout(new BorderLayout(20,20));


		north=new JPanel();
		north.setLayout(new FlowLayout(FlowLayout.CENTER));
		headerLB=new JLabel("Qualifying Test");
		headerLB.setFont(new Font("Verdana",0,20));
		north.add(headerLB);
		add(north,"North");

        imgPnlRef=new ImagePanel();
        regPnlRef=new RegisterPanel();
        loginPnlRef=new LoginPanel();
		center=new JPanel();
		center.setLayout(cards);
		center.add(imgPnlRef,"ImagePanel");
		center.add(regPnlRef,"RegisterPanel");
		center.add(loginPnlRef,"LoginPanel");
		cards.show(center,"ImagePanel");
		add(center,"Center");

		south=new JPanel();
		south.setLayout(new FlowLayout(FlowLayout.CENTER));
		registerB=new JButton("Registration");
		loginB=new JButton("Exam");

		registerB.addActionListener(this);
		loginB.addActionListener(this);

		south.add(registerB);
		south.add(loginB);

		add(south,"South");
       setVisible(true);
       clientThread=new ClientThread(this);

	}


	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==registerB)
		{
			this.cards.show(center,"RegisterPanel");
		}
		else if(ae.getSource()==loginB)
		{
			this.cards.show(center,"LoginPanel");
		}
	}
	public static void main(String args[])
	{
		 new ClientConsole();
	}
}

class ImagePanel extends JPanel                                        //ImagePanel
{
	ImageIcon image;
	JLabel imageLabel;
	ImagePanel()
	{
		setLayout(new BorderLayout(10,10));
	    image=new ImageIcon("window.jpg");
	    imageLabel=new JLabel(image,JLabel.CENTER);
	    add(imageLabel,"Center");
	}
}

class RegisterPanel extends JPanel implements ActionListener
{

	JTextField nameTF,branchTF,emailTF,collegeTF;
	JLabel nameLB,branchLB,emailLB,collegeLB;
	JButton registerB;
	JPanel center,south;
	TempFrame temp;

	RegisterPanel()
	{
		setLayout(new BorderLayout(20,50));
		center=new JPanel();
		center.setLayout(new GridLayout(7,2));
		nameTF=new JTextField(20);
		nameLB=new JLabel("Name");
		branchTF=new JTextField(20);
		branchLB=new JLabel("Branch");
		collegeTF=new JTextField(20);
		collegeLB=new JLabel("College");
		emailTF=new JTextField(20);
		emailLB=new JLabel("Email");

		center.add(nameLB);
		center.add(nameTF);
		center.add(branchLB);
		center.add(branchTF);
		center.add(collegeLB);
		center.add(collegeTF);
		center.add(emailLB);
		center.add(emailTF);
		add(center,"Center");

		south=new JPanel();
		south.setLayout(new FlowLayout(FlowLayout.CENTER));
		registerB=new JButton("Register");
		registerB.addActionListener(this);
		south.add(registerB);
		add(south,"South");
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==registerB)
		{
			try
		   {
			    System.out.println("register");
				System.out.println(this.nameTF.getText());
				System.out.println(this.branchTF.getText());
				System.out.println(this.collegeTF.getText());
				System.out.println(this.emailTF.getText());
		    	ActiveThreadOnClient.out.println("register");
		    	ActiveThreadOnClient.out.println(this.nameTF.getText());
		    	ActiveThreadOnClient.out.println(this.branchTF.getText());
		    	ActiveThreadOnClient.out.println(this.collegeTF.getText());
		    	ActiveThreadOnClient.out.println(this.emailTF.getText());
                 //temp=new TempFrame();
		    	//JOptionPane.showMessageDialog(temp,ActiveThreadOnClient.in.readLine());
		   }
		   catch(Exception e)
		   {
		    	System.out.println("Exception in Register Button : "+e);
		   }
	   }

	}
}

class LoginPanel extends JPanel implements ActionListener
{
	JPanel center,south;
	JLabel usernameLB,passwordLB;
	JTextField usernameTF;
	JPasswordField passwordPF;
	JButton loginB;
    TempFrame temp;
	LoginPanel()
	{
		setLayout(new BorderLayout(20,170));
		center=new JPanel();
		center.setLayout(new GridLayout(2,2));
		usernameLB=new JLabel("Username");
		passwordLB=new JLabel("Password");
		usernameTF=new JTextField(20);
		passwordPF=new JPasswordField(20);
		center.add(usernameLB);
		center.add(usernameTF);
		center.add(passwordLB);
		center.add(passwordPF);
		add(center,"Center");

		south=new JPanel();
		south.setLayout(new FlowLayout(FlowLayout.CENTER));
		loginB=new JButton("Login");
		loginB.addActionListener(this);
		south.add(loginB);
		add(south,"South");
	}

	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==loginB)
		{
			try
		    {
				System.out.println("login");
				System.out.println(this.usernameTF.getText());
				System.out.println(this.passwordPF.getText());
		    	ActiveThreadOnClient.out.println("login");
		    	ActiveThreadOnClient.out.println(this.usernameTF.getText());
		    	ActiveThreadOnClient.out.println(this.passwordPF.getText());
		    	//temp=new TempFrame();
		    	//JOptionPane.showMessageDialog(temp,ActiveThreadOnClient.in.readLine());
		    }
		    catch(Exception e)
		    {
		    	System.out.println("Exception in Login Button : "+e);
		    }
	     }
	}

}

class ClientThread extends Thread
{
	ClientConsole ref;
	Socket s=null;
	ClientThread(ClientConsole ref)
	{
		this.ref=ref;
		start();
	}

	public void run()
	{
		try
		{
			s=new Socket("127.0.0.1",4000);
		    new ActiveThreadOnClient(s,ref);
		}
		catch(Exception e)
		{
			System.out.println("Error in ClientThread: "+e);
		}
	}
}

class ActiveThreadOnClient extends Thread
{
	ClientConsole ref;
	Socket s;
	Date dt;
    static BufferedReader in;
    static PrintWriter out;
	ActiveThreadOnClient(Socket s,ClientConsole ref)
	{
		this.s=s;
		this.ref=ref;
		start();
	}

	public void run()
	{
		dt=new Date();
		try
		{
			 in=new BufferedReader(new InputStreamReader(s.getInputStream()));
		    out=new PrintWriter(s.getOutputStream(),true);
		    JOptionPane.showMessageDialog(ref,in.readLine());
		    out.println("Client : "+dt.getHours()+":"+dt.getMinutes()+":"+dt.getSeconds());
		}
		catch(Exception e)
		{
			System.out.println("Error in ActiveThreadOnClient: "+e);
		}
	}
}

class TempFrame extends JFrame
{
	TempFrame()
	{
		setSize(20,20);
		setVisible(false);
	}
}





