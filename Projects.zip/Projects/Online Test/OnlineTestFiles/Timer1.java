import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.Date;


class Timer1 extends JFrame implements ActionListener
{
	static JLabel time;
	JButton start;
	Timer1()
	{
		setSize(500,500);
		setLayout(new FlowLayout());
		time=new JLabel("00:00");
		start=new JButton("Start");
		start.addActionListener(this);
		add(start);
		add(time);
		setVisible(true);

	}

    public void actionPerformed(ActionEvent ae)
    {
		if(ae.getSource()==start)
		{
			new ChangeTime(this);
		}
	}

	public static void main(String args[])
	{
		new Timer1();

	}
}

class ChangeTime extends Thread
{
	int minutes,seconds;
	Timer1 ref;

	ChangeTime(Timer1 ref)
	{
		minutes=0;
		seconds=0;
		ref=this.ref;
		start();
	}

	public void run()
	{
		while(true)
		{
			seconds+=1;
			if(seconds==59)
			{
				minutes+=1;
				seconds=0;
			}

			Timer1.time.setText(minutes+":"+seconds);
			try
			{
				sleep(1000);
			}
			catch(Exception e)
			{
				e.toString();
			}
		}
	}
}


