import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.Date;


class Timer extends JFrame
{
	JLabel time;
	Timer()
	{
		setSize(500,500);
		setLayout(new FlowLayout());
		time=new JLabel("");
		add(time);

		Date dt;
		int minutes=0 ,seconds=0,startminutes=0,startseconds=0;
		dt=new Date();
		startminutes=dt.getMinutes();
		startseconds=dt.getSeconds();
		setVisible(true);
		while(true)
		{
			dt=new Date();
			minutes=dt.getMinutes()-startminutes;
			seconds=dt.getSeconds()-startseconds;
			//System.out.println(minutes+" : "+seconds);
			time.setText(minutes+" : "+seconds);
			if(minutes==1)
			{
				time.setText("Time Out");
				break;
			}
		}

	}

	public static void main(String args[])
	{
		new Timer();
	}
}
