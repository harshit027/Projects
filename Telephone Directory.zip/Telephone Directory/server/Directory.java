import java.io.*;
import java.net.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import javax.swing.*;

class Directory extends JFrame implements ActionListener
{
	JPanel southPanel,centerPanel;
	JMenuBar menuBar;
	JMenu menu;
	JMenuItem newEntry,delete,search,viewData,exit;
	ImageIcon image,imageOnBtn1,imageOnBtn2;
	JLabel head;
	JButton startButton;
	CardLayout cards=new CardLayout();
	RegisterPanel regPnlRef;
	SearchPanel searchPnlRef;
	ImagePanel imgPnlRef;
	DeletePanel delPnlRef;
	DatabaseFrame databaseFrmRef;
	static Socket s;
	static ServerSocket ss;
	static BufferedReader in;
	static PrintWriter out;
	String flag;
	String temp;
	String dataToUser[];
	Directory()
	{

		setSize(600,600);
		setTitle("MANAGER");
		getContentPane().setLayout(new BorderLayout(0,0));

		menuBar=new JMenuBar();
		menu=new JMenu("Record");
		setJMenuBar(menuBar);
		newEntry=new JMenuItem("New");
		viewData=new JMenuItem("ViewData");
		search=new JMenuItem("Search");
		delete=new JMenuItem("Delete");
		exit=new JMenuItem("Exit");
		newEntry.addActionListener(this);
		viewData.addActionListener(this);
		search.addActionListener(this);
		delete.addActionListener(this);
		exit.addActionListener(this);
		menu.setEnabled(false);
		menu.add(newEntry);
		menu.add(viewData);
		menu.add(search);
		menu.add(delete);
		menu.add(exit);
		menuBar.add(menu);

		regPnlRef=new RegisterPanel();
		searchPnlRef=new SearchPanel();
        imgPnlRef=new ImagePanel();
        delPnlRef=new DeletePanel();

		centerPanel=new JPanel();
		centerPanel.setLayout(cards);
		centerPanel.add(imgPnlRef,"ImagePanel");
		centerPanel.add(regPnlRef,"RegisterPanel");
		centerPanel.add(searchPnlRef,"SearchPanel");
		centerPanel.add(delPnlRef,"DeletePanel");
		getContentPane().add(centerPanel,"Center");
        cards.show(centerPanel,"ImagePanel");

        southPanel=new JPanel();
        southPanel.setLayout(new FlowLayout());
        imageOnBtn1=new ImageIcon("bell.gif");
        imageOnBtn2=new ImageIcon("globe.gif");
        startButton=new JButton("START",imageOnBtn1);
        startButton.setRolloverIcon(imageOnBtn2);
        startButton.addActionListener(this);
        southPanel.add(startButton);
        getContentPane().add(southPanel,"South");
		setVisible(true);
		/***********************************SocketCode**************************/
		try
		{
			ss=new ServerSocket(3400);
			System.out.println("Server Started");
		    s=ss.accept();
		    in=new BufferedReader(new InputStreamReader(s.getInputStream()));
		    out=new PrintWriter(s.getOutputStream(),true);
		    out.println("Client Connected : "+s);
		    flag=in.readLine();
		    System.out.println(flag);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		/***************************************************************************/
		String entriesFromClient[]=new String[5];
		try
		{
			for(int i=0;i<5;i++)
		    {
		    	entriesFromClient[i]=in.readLine();
		    	System.out.println(entriesFromClient[i]);
		    }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}

		if(flag.equals("register"))
		{
			try
			{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			    Connection con=DriverManager.getConnection("jdbc:odbc:directory");
			    PreparedStatement pst=con.prepareStatement("insert into users (user_name,phone,mobile,address,sex) values(?,?,?,?,?)");
			    pst.setString(1,entriesFromClient[0]);
			    pst.setString(2,entriesFromClient[1]);
			    pst.setString(3,entriesFromClient[2]);
			    pst.setString(4,entriesFromClient[3]);
			    pst.setString(5,entriesFromClient[4]);
			    int count=pst.executeUpdate();
			    if(count>0)
			    {
			    	out.println("You are registered !");
			    }
			    else
			    {
			    	out.println("Some error occured !");
			    }
			    pst.close();
			    con.close();
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}

		if(flag.equals("search"));
		{
			dataToUser=new String[6];
			try
			{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				Connection con=DriverManager.getConnection("jdbc:odbc:directory");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from users");
				while(rs.next())
				{
					if(rs.getString(2).equalsIgnoreCase(entriesFromClient[0]))
					{
						temp=rs.getString(1);
					}
				}
				rs.close();
				con.close();
			}
			catch(Exception e)
			{
				System.out.println("problem occured  "+e);
			}
			try
			{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				Connection con=DriverManager.getConnection("jdbc:odbc:directory");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from users where ID = "+temp);

				while(rs.next())
				{
					System.out.println(rs.getString(1));
				    System.out.println(rs.getString(2));
				    System.out.println(rs.getString(3));
				    System.out.println(rs.getString(4));
				    System.out.println(rs.getString(5));
				    System.out.println(rs.getString(6));
				}
				rs.close();
				con.close();
			}
			catch(Exception e)
			{
				System.out.println("problem occured  "+e);
		    }
		}
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==newEntry)
		{
			this.cards.show(centerPanel,"RegisterPanel");
		}
		if(ae.getSource()==search)
		{
			this.cards.show(centerPanel,"SearchPanel");
		}
		if(ae.getSource()==delete)
		{
			this.cards.show(centerPanel,"DeletePanel");
		}
		if(ae.getSource()==exit)
		{
			int check=JOptionPane.showConfirmDialog(this,"Are you sure !");
			if(check==JOptionPane.YES_OPTION)
			System.exit(0);
		}
		if(ae.getSource()==viewData)
		{
			databaseFrmRef=new DatabaseFrame();
		}
		if(ae.getSource()==startButton)
		{
			this.menu.setEnabled(true);
			this.startButton.setVisible(false);
		}
	}

	public static void main(String args[])
	{
		new Directory();
	}
}

class ImagePanel extends JPanel
{
	ImageIcon image;
	JLabel imageLabel;
	ImagePanel()
	{
		setLayout(new BorderLayout(10,10));
	    image=new ImageIcon("window.jpg");
	    imageLabel=new JLabel(image,JLabel.CENTER);
	    add(imageLabel,"Center");
	}
}

class RegisterPanel extends JPanel implements ActionListener
{
	JPanel centerPanel,southPanel;
	JButton registerButton;
	JTextField nameTF,phoneTF,mobileTF;
	JTextArea addressTA;
	JLabel nameLB,phoneLB,mobileLB,addressLB,sexLB;
	JComboBox sexCB;

    ImageIcon image;

	RegisterPanel()
	{
		setLayout(new BorderLayout(0,10));
		JLabel heading=new JLabel("REGISTRATION",JLabel.CENTER);
		heading.setFont(new Font("Verdana",Font.BOLD,20));
		add(heading,"North");

		centerPanel=new JPanel();
		centerPanel.setBackground(Color.lightGray);
		centerPanel.setLayout(new GridLayout(6,3,0,60));
		nameLB=new JLabel("Name");
		phoneLB=new JLabel("Phone");
		mobileLB=new JLabel("Mobile");
		addressLB=new JLabel("Address");
		sexLB=new JLabel("Sex");


		nameTF=new JTextField(20);
		phoneTF=new JTextField(20);
		mobileTF=new JTextField(20);
		addressTA=new JTextArea();

		sexCB=new JComboBox();
		sexCB.addItem("MALE");
		sexCB.addItem("FEMALE");

		centerPanel.add(nameLB);
		centerPanel.add(nameTF);
		centerPanel.add(phoneLB);
		centerPanel.add(phoneTF);
		centerPanel.add(mobileLB);
		centerPanel.add(mobileTF);
		centerPanel.add(addressLB);
		centerPanel.add(addressTA);
		centerPanel.add(sexLB);
		centerPanel.add(sexCB);
		add(centerPanel,"Center");

		southPanel=new JPanel();
		southPanel.setLayout(new FlowLayout());
		registerButton=new JButton("REGISTER");
		registerButton.addActionListener(this);
		southPanel.add(registerButton);
		add(southPanel,"South");

		image=new ImageIcon("MSN.jpg");
		JLabel imgLabel=new JLabel(image,JLabel.CENTER);
		add(imgLabel,"East");
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==registerButton)
		{
			String temp=this.sexCB.getSelectedItem()+"";
			try
			{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			    Connection con=DriverManager.getConnection("jdbc:odbc:directory");
			    PreparedStatement pst=con.prepareStatement("insert into users (user_name,phone,mobile,address,sex) values(?,?,?,?,?)");
			    pst.setString(1,this.nameTF.getText());
			    pst.setString(2,this.phoneTF.getText());
			    pst.setString(3,this.mobileTF.getText());
			    pst.setString(4,this.addressTA.getText());
			    pst.setString(5,temp);
			    int count=pst.executeUpdate();
			    if(count>0)
			    {
			    	JOptionPane.showMessageDialog(this,"Saved successfully");
			    }
			    else
			    {
			    	JOptionPane.showMessageDialog(this,"Error in saving");
			    }
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			nameTF.setText(null);
			phoneTF.setText(null);
			mobileTF.setText(null);
			addressTA.setText(null);
		}

	}
}

class SearchPanel extends JPanel implements ActionListener
{
	JPanel centerPanel;
	JButton searchBtn;
	JLabel heading,nameLB;
	public static JTextField nameTF;
	ImageIcon image;
	SearchPanel()
	{
		setLayout(new BorderLayout(0,10));

		heading=new JLabel("SEARCH",JLabel.CENTER);
		heading.setFont(new Font("Verdana",Font.BOLD,20));
		add(heading,"North");

		centerPanel=new JPanel();
		centerPanel.setBackground(Color.lightGray);
		centerPanel.setLayout(new FlowLayout(FlowLayout.LEFT,30,80));
		nameLB=new JLabel("Name");
		nameTF=new JTextField(20);
        searchBtn=new JButton("SEARCH");
        searchBtn.addActionListener(this);
        JLabel temp=new JLabel("                          ");
		centerPanel.add(nameLB);
		centerPanel.add(nameTF);
		centerPanel.add(temp);
		centerPanel.add(searchBtn);

		add(centerPanel,"Center");

		image=new ImageIcon("PID.jpg");
		JLabel imgLabel=new JLabel(image,JLabel.CENTER);
		add(imgLabel,"East");
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==searchBtn)
		{
			new SearchResultFrame();
		}
	}
}

class SearchResultFrame extends JFrame
{
	JTable table;
	String data[][];
	String heads[]={"UserID","Name","Phone","Mobile","Address","Sex"};
	String temp;
	SearchResultFrame ()
	{
		setSize(500,500);
		setTitle("Search Results");
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con=DriverManager.getConnection("jdbc:odbc:directory");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from users");
			while(rs.next())
			{
				if(rs.getString(2).equalsIgnoreCase(SearchPanel.nameTF.getText()))
				{
					temp=rs.getString(1);
				}
			}
			rs.close();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println("problem occured  "+e);
		}
		try
		{
			data=new String[1][6];
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con=DriverManager.getConnection("jdbc:odbc:directory");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from users where ID = "+temp);

			while(rs.next())
			{
				data[0][0]=rs.getString(1);
			    data[0][1]=rs.getString(2);
			    data[0][2]=rs.getString(3);
			    data[0][3]=rs.getString(4);
				data[0][4]=rs.getString(5);
				data[0][5]=rs.getString(6);

			}
			rs.close();
			con.close();
		}
		catch(Exception e)
		{
			System.out.println("problem occured  "+e);
		}
		SearchPanel.nameTF.setText(null);
		table=new JTable(data,heads);
		JScrollPane jsp=new JScrollPane(table);
		getContentPane().add(jsp);
        setVisible(true);
	}
}

class DeletePanel extends JPanel implements ActionListener
{
	JPanel centerPanel;
	JButton deleteBtn;
	JLabel heading,idLB;
	JTextField idTF;
	ImageIcon image;

	DeletePanel()
	{
		setLayout(new BorderLayout(0,10));

		heading=new JLabel("DELETE",JLabel.CENTER);
		heading.setFont(new Font("Verdana",Font.BOLD,20));
		add(heading,"North");

		centerPanel=new JPanel();
		centerPanel.setBackground(Color.lightGray);
		centerPanel.setLayout(new FlowLayout(FlowLayout.LEFT,30,80));
		idLB=new JLabel("User ID");
		idTF=new JTextField(20);
        deleteBtn=new JButton("DELETE");
        deleteBtn.addActionListener(this);
        JLabel temp=new JLabel("                          ");
		centerPanel.add(idLB);
		centerPanel.add(idTF);
		centerPanel.add(temp);
		centerPanel.add(deleteBtn);

		add(centerPanel,"Center");

		image=new ImageIcon("PID.jpg");
		JLabel imgLabel=new JLabel(image,JLabel.CENTER);
		add(imgLabel,"East");
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==deleteBtn)
		{
			try
			{
				String id=this.idTF.getText();
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				Connection con=DriverManager.getConnection("jdbc:odbc:directory");
				PreparedStatement pst=con.prepareStatement("delete from users where ID=?");
				pst.setString(1,id);
				pst.executeUpdate();
				JOptionPane.showMessageDialog(this,"Record Deleted !");
				pst.close();
				con.close();
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(this,"Problem in deleting !");
				e.toString();
			}
			this.idTF.setText(null);
		}
	}
}

class DatabaseFrame extends JFrame
{
	JTable table;
	String data[][];
	String heads[]={"UserID","Name","Phone","Mobile","Address","Sex"};
	int i;
	DatabaseFrame()
	{
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection tempCon=DriverManager.getConnection("jdbc:odbc:directory");
			Statement st=tempCon.createStatement();
			ResultSet tempRs=st.executeQuery("select * from users");

			while(tempRs.next())
			{
				i++;
			}
			tempRs.close();
			tempCon.close();
		}
		catch(Exception e)
		{
			e.toString();
		}
		setSize(500,500);
		setTitle("Records");
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con=DriverManager.getConnection("jdbc:odbc:directory");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from users");
			data=new String[i][6];
			i=0;
			while(rs.next())
			{
				data[i][0]=rs.getString(1);
				data[i][1]=rs.getString(2);
				data[i][2]=rs.getString(3);
				data[i][3]=rs.getString(4);
				data[i][4]=rs.getString(5);
				data[i][5]=rs.getString(6);
				i++;
			}
			rs.close();
			con.close();
		}
		catch(Exception e)
		{
			e.toString();
		}
		table=new JTable(data,heads);
		JScrollPane jsp=new JScrollPane(table);
		getContentPane().add(jsp);
        setVisible(true);
	}
}







