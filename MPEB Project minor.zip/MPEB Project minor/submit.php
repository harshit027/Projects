<?php
$bill_month=$_POST["bill_month"];
$yr=$_POST["yr"];
$reading=$_POST["reading"];
$type_read=$_POST["type_read"];
$f_reading=$_POST["f_reading"];
$i_reading=$_POST["i_reading"];
$c_reading=$_POST["c_reading"];
$assessment=$_POST["assessment"];
$custn=$_POST["custn"];
if($type_read==1|| $type_read==2 )
{
$f_reading=0;
$i_reading=0;
}
$db=mysql_connect("localhost","root","") or die("nahi chala");
mysql_select_db("bill",$db) or die ("error1 ".mysql_error());
$query="INSERT INTO entry (bill_mon,yr,read_date,type_red,final_red,ini_read,ass,cur_read,custn) VALUES ($bill_month,$yr,$reading,$type_read,$f_reading,$i_reading,$assessment,$c_reading,$custn)";
$result=mysql_query($query);
?>