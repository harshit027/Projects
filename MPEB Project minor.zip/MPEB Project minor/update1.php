<?php
header('Content-Type: text/xml');
$final_red = $_GET['final_red'];
$db=mysql_connect("localhost","root","") or die('nahi chali');
mysql_select_db("bill",$db) or die ("error1 ".mysql_error());
$query="SELECT final_red FROM entry WHERE type_red = '$final_red'";
$result=mysql_query($query) or die("error2 ".mysql_error());
$save = mysql_fetch_assoc($result);
$html = $save['final_red'];
if (!$html) $html = 'invalid entry';
$dom = new DOMDocument();
$response = $dom->createElement('response');
$dom->appendChild($response);
$responseText = $dom->createTextNode ($html);
$response->appendChild($responseText);
$xmlString = $dom->saveXML();
echo $xmlString;
?>