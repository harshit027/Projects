<?php
header('Content-Type: text/xml');
$db=mysql_connect("localhost","root","") or die('nahi chali');
mysql_select_db("bill",$db) or die ("error1 ".mysql_error());
$value1 =$_GET['value1']; 
$value = $_GET['value'];
if($value)
	{
	$query="SELECT location FROM entry WHERE location_code = '$value'";
	$result=mysql_query($query) or die("error2 ".mysql_error());
	$save = mysql_fetch_assoc($result);
	$html = $save['location'];
	if (!$html) $html = 'invalid entry';
	$dom = new DOMDocument();
	$response = $dom->createElement('response');
	$dom->appendChild($response);
	$responseText = $dom->createTextNode ($html);
	$response->appendChild($responseText);
      }
	elseif($value1)
	{
	$query="SELECT cus_name,pre_reading FROM entry WHERE cus_no = '$value1'";
	$result=mysql_query($query) or die("error2 ".mysql_error());
	$save = mysql_fetch_assoc($result);
	
	$dom = new DOMDocument();
	
	$response = $dom->createElement('response');
	$dom->appendChild($response);
      
	$cus_name = $dom->createElement('cus_name');
	$response->appendChild($cus_name);
	
	$html = $save['cus_name'];
	if (!$html) $html = 'invalid entry';
	$responseText = $dom->createTextNode ($html);
	$cus_name->appendChild($responseText);
	
	$reading = $dom->createElement('pre_reading');
	$response->appendChild($reading);
	
	$html = $save['pre_reading'];
	if (!$html) $html = 'invalid entry';	
	$responseText = $dom->createTextNode ($html);
	$reading->appendChild($responseText);

	}
	$xmlString = $dom->saveXML();
	echo $xmlString;
?>